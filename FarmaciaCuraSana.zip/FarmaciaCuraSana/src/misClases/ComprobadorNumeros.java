
package misClases;

public class ComprobadorNumeros {
    
public static boolean esNumero(String cadena) {
    boolean esNumero = true;
    try {
        int numero = Integer.parseInt(cadena);
        if (numero <= 0) { // Verificar si el número es menor o igual a cero
            esNumero = false;
        }
    } catch (NumberFormatException e) {
        esNumero = false;
    }
    return esNumero;
}

    
 public static boolean esNumeroDecimal(String cadena) {
    boolean esNumeroDecimal = true;
    try {
        double numero = Double.parseDouble(cadena);
        if (numero <= 0) { // Verificar si el número es menor o igual a cero
            esNumeroDecimal = false;
        }
    } catch (NumberFormatException e) {
        esNumeroDecimal = false;
    }
    return esNumeroDecimal;
}

}

