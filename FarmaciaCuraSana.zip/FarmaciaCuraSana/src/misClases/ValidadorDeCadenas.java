
package misClases;

public class ValidadorDeCadenas {
    public static boolean contieneSoloLetras(String cadena) {
        return cadena.matches("^[a-zA-ZñÑ&\\s]+$");
    }
    
    public static boolean contieneLetrasyNumeros(String cadena) {
        return cadena.matches("[a-zA-Z0-9\\s]+");
    }
}
