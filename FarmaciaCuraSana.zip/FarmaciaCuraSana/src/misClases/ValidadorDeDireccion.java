package misClases;

import java.util.regex.Pattern;

public class ValidadorDeDireccion {

    public static boolean esDireccionValida(String direccion) {
        if (direccion == null || direccion.trim().isEmpty()) {
            return false;
        }

        String patron = "^[a-zA-Zñ0-9\\/.,\\s]*$";
        Pattern patronRegex = Pattern.compile(patron);

        return patronRegex.matcher(direccion).matches();
    }
}
