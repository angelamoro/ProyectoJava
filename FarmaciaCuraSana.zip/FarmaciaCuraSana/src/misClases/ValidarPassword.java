package misClases;

public class ValidarPassword {

    /*Tiene una longitud mínima de 8 caracteres y máxima de 20 caracteres.
    Contiene al menos una letra minúscula, una letra mayúscula, un número y un carácter especial (@#$%^&+=!).
     No contiene espacios en blanco*/
    
    private final int LONGITUD_MINIMA = 8;
    private final int LONGITUD_MAXIMA = 20;
    private final String PATRON = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[*@#$%^&+=!])(?=\\S+$).{"
            + LONGITUD_MINIMA + "," + LONGITUD_MAXIMA + "}$";

    public boolean esValida(String contrasena) {
        return contrasena.matches(PATRON);
    }

    public void validarContrasena(String contrasena) {
        ValidarPassword validador = new ValidarPassword();
        if (validador.esValida(contrasena)) {
            System.out.println("La contraseña es válida");
        } else {
            System.out.println("La contraseña no cumple los requisitos de seguridad");
        }
    }
}
