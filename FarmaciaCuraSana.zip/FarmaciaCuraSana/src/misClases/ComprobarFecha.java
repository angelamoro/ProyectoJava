package misClases;

import java.util.Date;

public class ComprobarFecha {

    public static boolean esFechaPosterior(Date fecha) {
        Date fechaActual = new Date();
        return fecha.after(fechaActual);
    }
}
