package misClases;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Redondeador {

    public static double redondear(double numero, int cant) {
        BigDecimal bd = new BigDecimal(numero).setScale(2, RoundingMode.HALF_UP);
        DecimalFormat df = new DecimalFormat("#,##0.00");
        df.setDecimalSeparatorAlwaysShown(false);
        String resultado = df.format(bd).replace(",", ".");
        return Double.parseDouble(resultado);
    }
}
