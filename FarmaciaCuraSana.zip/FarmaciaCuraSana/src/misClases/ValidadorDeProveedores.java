package misClases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ValidadorDeProveedores {

    public static boolean existeProveedor(String nombreProveedor, Connection conexion) throws SQLException {
        String consulta = "SELECT * FROM Proveedores WHERE Empresa = ?";
        PreparedStatement sentencia = conexion.prepareStatement(consulta);
        sentencia.setString(1, nombreProveedor);
        ResultSet resultado = sentencia.executeQuery();
        return resultado.next();
    }
}
