
package misClases;

public class ValidadorDeTelefono {
    public static boolean esValido(String telefono) {
        // El número de teléfono debe tener entre 9 y 12 dígitos y no contener caracteres que no sean números
        return telefono.matches("^[0-9]{9,12}$");
    }
}