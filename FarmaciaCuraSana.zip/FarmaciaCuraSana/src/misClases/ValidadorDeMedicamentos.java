
package misClases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ValidadorDeMedicamentos {
    private Connection conexion;
    
    public ValidadorDeMedicamentos(Connection conexion) {
        this.conexion = conexion;
    }
    
    public boolean existeMedicamento(String nombre) throws SQLException {
        boolean existe = false;
        
        String consulta = "SELECT COUNT(*) FROM Medicamentos WHERE Nombre = ?";
        PreparedStatement sentencia = conexion.prepareStatement(consulta);
        sentencia.setString(1, nombre);
        ResultSet resultado = sentencia.executeQuery();
        
        if (resultado.next()) {
            int numFilas = resultado.getInt(1);
            if (numFilas > 0) {
                existe = true;
            }
        }
        
        return existe;
    }
}
