
package misClases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ComprobadorDeEmpleado {
    private Connection conexion;

    public ComprobadorDeEmpleado(Connection conexion) {
        this.conexion = conexion;
    }

    public boolean existeEmpleadoConNombre(String usuario) throws SQLException {
        String consulta = "SELECT COUNT(*) FROM Empleados WHERE usuario = ?";
        PreparedStatement sentencia = conexion.prepareStatement(consulta);
        sentencia.setString(1, usuario);
        ResultSet resultado = sentencia.executeQuery();
        resultado.next();
        return resultado.getInt(1) > 0;
    }
    
}
