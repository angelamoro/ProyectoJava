package misClases;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import javax.swing.JTable;

public class ImprimePDF {

    public static void generaPDF(String filePath, LocalDate fecha, double total, JTable table) {
        try {
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            // Agregar logo
            Image logo = Image.getInstance("src/Images/Encabezado.png");
            logo.scaleToFit(600, 200);
            document.add(logo);

            //Agregar espacio
            Paragraph espacio = new Paragraph("\n");
            document.add(espacio);

            // Agregar fecha
            Paragraph fechaParagraph = new Paragraph("Fecha: " + fecha.toString() + "\n");
            document.add(fechaParagraph);

            // Agregar espacio en blanco
            for (int i = 0; i < 2; i++) {
                espacio = new Paragraph("\n");
                document.add(espacio);
            }

            // Agregar tabla
            PdfPTable pdfTable = new PdfPTable(table.getColumnCount());
            addTableHeader(pdfTable, table);
            addTableData(pdfTable, table);


            // Configurar alineación centrada para todas las celdas de la tabla
            for (int i = 0; i < pdfTable.getRows().size(); i++) {
                for (int j = 0; j < pdfTable.getRow(i).getCells().length; j++) {
                    PdfPCell cell = pdfTable.getRow(i).getCells()[j];
                    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                }
            }

            document.add(pdfTable);

            //Agregar espacio
            espacio = new Paragraph("\n");
            document.add(espacio);

            // Agregar total
            Paragraph totalParagraph = new Paragraph("Total factura: " + total);
            totalParagraph.setAlignment(Element.ALIGN_RIGHT);
            document.add(totalParagraph);

            document.close();
            System.out.println("Factura generada correctamente.");
        } catch (DocumentException | IOException e) {
            e.printStackTrace();
        }
    }

    private static void addTableHeader(PdfPTable table, JTable jTable) {
        for (int i = 0; i < jTable.getColumnCount(); i++) {
            PdfPCell cell = new PdfPCell(new Phrase(jTable.getColumnName(i)));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
        }
    }

    private static void addTableData(PdfPTable table, JTable jTable) {
        for (int i = 0; i < jTable.getRowCount(); i++) {
            for (int j = 0; j < jTable.getColumnCount(); j++) {
                table.addCell(jTable.getValueAt(i, j).toString());
            }
        }
    }
}
