package misClases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    // Atributos de la clase
    private static Connection conexion;
    private static final String esquema = "jdbc:mysql://localhost/Farmacia?autoReconnect=true&useSSL=false";
    private static final String usuario = "farmaceutico";
    private static final String password = "Farmaceutico";

    // Método para obtener la conexión
    public static Connection getConnection() throws SQLException {
        if (conexion == null) {
            // Cargar el controlador JDBC
            try {
                Class.forName("com.mysql.jdbc.Driver");
                // Establecer la conexión
                conexion = DriverManager.getConnection(esquema, usuario, password);
                System.out.println("Conexión establecida con éxito");
            } catch (ClassNotFoundException e) {
                System.out.println("No se pudo establecer la conexión");
                e.printStackTrace();
            }

        }
        return conexion;
    }

    // Método para cerrar la conexión
    public static void closeConnection() throws SQLException {
        if (conexion != null) {
            conexion.close();
            System.out.println("Conexión cerrada con éxito");
        }

    }
}
