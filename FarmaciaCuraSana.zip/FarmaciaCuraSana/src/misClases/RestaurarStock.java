
package misClases;

import static farmaciacurasana.Ventas.conexion;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RestaurarStock {
    private String nombre;
    private int cantidadNoVendida;
    private int stockOriginal;

    public RestaurarStock(String nombre, int cantidadNoVendida) {
        this.nombre = nombre;
        this.cantidadNoVendida = cantidadNoVendida;
    }

    public int restaurarStock() {
        try {
            String consulta = "UPDATE Medicamentos SET stock = stock + ? WHERE nombre = ?";
            PreparedStatement actualizacion = conexion.prepareStatement(consulta);
            actualizacion.setInt(1, cantidadNoVendida);
            actualizacion.setString(2, nombre);
            actualizacion.executeUpdate();
            return stockOriginal + cantidadNoVendida;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return -1; // Si algo va mal, devuelve -1
        }
    }
}

