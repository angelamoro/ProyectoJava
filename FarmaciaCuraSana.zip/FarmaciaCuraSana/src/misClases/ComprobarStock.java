package misClases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ComprobarStock {
    
    private Connection conexion;
    
    public ComprobarStock(Connection conexion) {
        this.conexion = conexion;
    }

    public int hayStock(String nombreMedicamento, int cantidadVenta) throws SQLException {
        String consulta = "SELECT stock FROM Medicamentos WHERE nombre = ?";
        PreparedStatement ps = conexion.prepareStatement(consulta);
        ps.setString(1, nombreMedicamento);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            int stock = rs.getInt(1);
            if (stock >= cantidadVenta) {
                return stock;
            }
        }
        return -1;
    }  
}


