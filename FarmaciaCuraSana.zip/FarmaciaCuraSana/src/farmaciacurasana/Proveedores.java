package farmaciacurasana;

import java.awt.Point;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import misClases.ValidadorDeProveedores;
import misClases.Conexion;
import misClases.ValidadorDeCadenas;
import misClases.ValidadorDeDireccion;
import static misClases.ValidadorDeTelefono.esValido;
import net.proteanit.sql.DbUtils;

public class Proveedores extends javax.swing.JFrame {

    public Proveedores() {
        initComponents();
        //Abro la conexion
        try {
            conexion = Conexion.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexión con la base de datos.");
            System.exit(0);
        }
        //Cambiar el icono
        setIconImage(new ImageIcon(getClass().getResource("../Images/logo .png")).getImage());
        MostrarProv();
        usuario.setText(Login.loggedInUser);
        //Desplazar ventana
        jPanel1 = new JPanel();
        frame = this;
    }

    public static Connection conexion;
    public static Statement st = null;
    public static ResultSet rs = null;
    private static Point initialClick;
    private JFrame frame;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        BrandProv = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        LogoProv = new javax.swing.JLabel();
        ProvMenuGest = new javax.swing.JLabel();
        ProvMenuMed = new javax.swing.JLabel();
        ProvMenuVtas = new javax.swing.JLabel();
        MedCant1 = new javax.swing.JLabel();
        usuario = new javax.swing.JLabel();
        logOut = new javax.swing.JButton();
        ProvTitle = new javax.swing.JLabel();
        ProvName = new javax.swing.JLabel();
        ProvDir = new javax.swing.JLabel();
        ProvEmp = new javax.swing.JLabel();
        ProvTlf = new javax.swing.JLabel();
        contacto = new javax.swing.JTextField();
        direccion = new javax.swing.JTextField();
        ProvAdd = new javax.swing.JButton();
        ProvEdit = new javax.swing.JButton();
        ProvDel = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ProvTb = new javax.swing.JTable();
        ProvListTitle = new javax.swing.JLabel();
        ProvX = new javax.swing.JLabel();
        telf = new javax.swing.JTextField();
        empresa = new javax.swing.JTextField();
        GestCons = new javax.swing.JButton();
        MedTabRefresh = new javax.swing.JButton();
        minimizar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel1MouseDragged(evt);
            }
        });
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 153, 255));

        BrandProv.setFont(new java.awt.Font("Dubai", 1, 36)); // NOI18N
        BrandProv.setForeground(new java.awt.Color(255, 255, 255));
        BrandProv.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BrandProv.setText("Cura Sana");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        LogoProv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logo .png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LogoProv)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LogoProv)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        ProvMenuGest.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        ProvMenuGest.setForeground(new java.awt.Color(255, 255, 255));
        ProvMenuGest.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ProvMenuGest.setText("Empleados");
        ProvMenuGest.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ProvMenuGestMousePressed(evt);
            }
        });

        ProvMenuMed.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        ProvMenuMed.setForeground(new java.awt.Color(255, 255, 255));
        ProvMenuMed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ProvMenuMed.setText("Almacen");
        ProvMenuMed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ProvMenuMedMousePressed(evt);
            }
        });

        ProvMenuVtas.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        ProvMenuVtas.setForeground(new java.awt.Color(255, 255, 255));
        ProvMenuVtas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ProvMenuVtas.setText("Ventas");
        ProvMenuVtas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ProvMenuVtasMousePressed(evt);
            }
        });

        MedCant1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedCant1.setForeground(new java.awt.Color(255, 255, 255));
        MedCant1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedCant1.setText("Usuario:");

        usuario.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        usuario.setForeground(new java.awt.Color(255, 255, 255));
        usuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        usuario.setText("usuario");

        logOut.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        logOut.setText("Salir");
        logOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logOutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BrandProv, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(ProvMenuMed, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
            .addComponent(ProvMenuGest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(ProvMenuVtas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(MedCant1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(usuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(logOut)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BrandProv)
                .addGap(36, 36, 36)
                .addComponent(ProvMenuMed)
                .addGap(18, 18, 18)
                .addComponent(ProvMenuGest)
                .addGap(18, 18, 18)
                .addComponent(ProvMenuVtas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 193, Short.MAX_VALUE)
                .addComponent(MedCant1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(usuario)
                .addGap(18, 18, 18)
                .addComponent(logOut, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43))
        );

        ProvTitle.setFont(new java.awt.Font("Dubai", 1, 36)); // NOI18N
        ProvTitle.setForeground(new java.awt.Color(0, 0, 0));
        ProvTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ProvTitle.setText("Proveedores");

        ProvName.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        ProvName.setForeground(new java.awt.Color(0, 0, 0));
        ProvName.setText("Contacto:");

        ProvDir.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        ProvDir.setForeground(new java.awt.Color(0, 0, 0));
        ProvDir.setText("Dirección:");

        ProvEmp.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        ProvEmp.setForeground(new java.awt.Color(0, 0, 0));
        ProvEmp.setText("Empresa:");

        ProvTlf.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        ProvTlf.setForeground(new java.awt.Color(0, 0, 0));
        ProvTlf.setText("Teléfono:");

        ProvAdd.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        ProvAdd.setText("Añadir");
        ProvAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProvAddActionPerformed(evt);
            }
        });

        ProvEdit.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        ProvEdit.setText("Actualizar");
        ProvEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProvEditActionPerformed(evt);
            }
        });

        ProvDel.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        ProvDel.setText("Eliminar");
        ProvDel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProvDelActionPerformed(evt);
            }
        });

        ProvTb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Dirección", "Empresa", "Teléfono"
            }
        ));
        ProvTb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ProvTbMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(ProvTb);

        ProvListTitle.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        ProvListTitle.setForeground(new java.awt.Color(0, 0, 0));
        ProvListTitle.setText("Listado de proveedores");

        ProvX.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        ProvX.setForeground(new java.awt.Color(0, 153, 255));
        ProvX.setText("X");
        ProvX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ProvXMousePressed(evt);
            }
        });

        GestCons.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        GestCons.setText("Consultar");
        GestCons.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GestConsActionPerformed(evt);
            }
        });

        MedTabRefresh.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedTabRefresh.setText("Refrescar");
        MedTabRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedTabRefreshActionPerformed(evt);
            }
        });

        minimizar.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        minimizar.setForeground(new java.awt.Color(0, 153, 255));
        minimizar.setText("-");
        minimizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                minimizarMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(232, 232, 232)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(ProvEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(54, 54, 54)
                                .addComponent(ProvDel, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(ProvListTitle)
                                .addGap(66, 66, 66)
                                .addComponent(MedTabRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(ProvTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(91, 91, 91)
                                        .addComponent(minimizar)
                                        .addGap(18, 18, 18))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(GestCons, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(328, 328, 328))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addComponent(ProvName, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(contacto, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addGap(1, 1, 1)
                                                                .addComponent(ProvDir)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(direccion, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                        .addGap(82, 82, 82)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(ProvTlf)
                                                            .addComponent(ProvEmp))))
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(telf, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(empresa, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 656, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(12, 12, 12)))
                                .addComponent(ProvX))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(216, 216, 216)
                                .addComponent(ProvAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(1, 35, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ProvX)
                            .addComponent(minimizar)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(ProvTitle)))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ProvEmp)
                            .addComponent(empresa, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ProvTlf)
                            .addComponent(telf, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ProvName)
                            .addComponent(contacto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(direccion, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ProvDir))))
                .addGap(54, 54, 54)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ProvAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ProvEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ProvDel, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(GestCons, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ProvListTitle)
                    .addComponent(MedTabRefresh))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 108, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    //Mostrar la tabla proveedores
    public void MostrarProv() {
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(" SELECT * FROM Proveedores");
            ProvTb.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + e.getMessage());
        }
    }

    //Vaciar los display de texto
    public void Clear() {
        contacto.setText("");
        direccion.setText("");
        empresa.setText("");
        telf.setText("");
    }

//Cerrar la aplicación
    private void ProvXMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProvXMousePressed
        try {
            // Cerrar el objeto Statement
            if (st != null) {
                st.close();
            }
            // Cerrar la conexión a la base de datos
            if (conexion != null) {
                Conexion.closeConnection();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        dispose();//Cierra la pantalla
    }//GEN-LAST:event_ProvXMousePressed

    //Cambiar a las distintas pantallas
    private void ProvMenuMedMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProvMenuMedMousePressed
        new Medicamentos().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ProvMenuMedMousePressed

    private void ProvMenuGestMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProvMenuGestMousePressed
        new Empleados().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ProvMenuGestMousePressed

    private void ProvMenuVtasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProvMenuVtasMousePressed
        new Ventas().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ProvMenuVtasMousePressed

    //Añadir proveedor
    private void ProvAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProvAddActionPerformed
        //Comprobar que los campos mínimos están llenos
        if (empresa.getText().isEmpty() || telf.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce los datos que faltan para poder continuar");
        }
        // Validar que el campo de contacto solo contiene letras si no está vacío
        if (!contacto.getText().trim().isEmpty()) {
            if (!ValidadorDeCadenas.contieneSoloLetras(contacto.getText().trim())) {
                JOptionPane.showMessageDialog(this, "El campo contacto solo debe contener letras");
                return;
            }
        }
        // Validar que el campo de empresa solo contiene letras
        if (!ValidadorDeCadenas.contieneSoloLetras(empresa.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo empresa solo debe contener letras");
            return;
        }

        // Validar que el campo de dirección cumple los requisitos
        if (!direccion.getText().trim().isEmpty()) {
            if (!ValidadorDeDireccion.esDireccionValida(direccion.getText().trim())) {
                JOptionPane.showMessageDialog(this, "El campo dirección solo debe contener letras (mayúsculas y minúsculas), números, barras diagonales, comas y puntos");
                return;
            }
        }
        //Comprobar que el teléfono cumple con las especificaciones
        if (!esValido(telf.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El teléfono debe tener entre 9 y 12 dígitos y no contener caracteres que no sean números.");
            return;
        }

        //Comprobar si el proveedor ya existe
        try {
            if (ValidadorDeProveedores.existeProveedor(empresa.getText().trim(), conexion)) {
                JOptionPane.showMessageDialog(this, "Ya existe un proveedor para esa empresa, por favor introduce una empresa nueva");
                return;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }

        //Comprobación
        int opcion = JOptionPane.showOptionDialog(
                null,
                "¿Quieres continuar?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new Object[]{"Continuar", "Cancelar"},
                "Continuar");

        if (opcion == JOptionPane.YES_OPTION) {
            try {
                //Creo la consulta
                String consulta = "INSERT INTO Proveedores (contacto, direccion, empresa, telefono) values (?, ?, ?, ?);";
                PreparedStatement sentencia = conexion.prepareStatement(consulta);
                sentencia.setString(1, contacto.getText().trim());
                sentencia.setString(2, direccion.getText().trim());
                sentencia.setString(3, empresa.getText().trim());
                sentencia.setString(4, telf.getText().trim());
                int row = sentencia.executeUpdate();
                JOptionPane.showMessageDialog(this, "Proveedor añadido correctamente");
                MostrarProv();
                Clear();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());
            }
        } else if (opcion == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "La operación ha sido cancelada");
        }

    }//GEN-LAST:event_ProvAddActionPerformed

    //Eliminar proveedor
    private void ProvDelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProvDelActionPerformed
        //Comprueba que el campo no está vacío
        if (empresa.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce los datos del proveedor a eliminar");
        }
// Validar que el campo de empresa solo contiene letras
        if (!ValidadorDeCadenas.contieneSoloLetras(empresa.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo empresa solo debe contener letras");
            return;
        }
        //Comprobar si el proveedor existe
        try {
            if (!ValidadorDeProveedores.existeProveedor(empresa.getText().trim(), conexion)) {
                JOptionPane.showMessageDialog(this, "No existe ese proveedor, por favor introduce nuevos datos");
                return;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
        }

        //Comprobación
        int opcion = JOptionPane.showOptionDialog(
                null,
                "¿Quieres continuar?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new Object[]{"Continuar", "Cancelar"},
                "Continuar");

        if (opcion == JOptionPane.YES_OPTION) {
            try {
                //Creo la consulta
                String consulta = "DELETE FROM proveedores WHERE idProveedor = (SELECT IdProveedor FROM (SELECT * FROM proveedores) AS p WHERE p.empresa = ?)";
                PreparedStatement sentencia = conexion.prepareStatement(consulta);
                sentencia.setString(1, empresa.getText().trim());
                int row = sentencia.executeUpdate();
                JOptionPane.showMessageDialog(this, "Proveedor eliminado correctamente");
                MostrarProv();
                Clear();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());
            }
        } else if (opcion == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "La operación ha sido cancelada");
        }
    }//GEN-LAST:event_ProvDelActionPerformed

    //Vaciar la tabla y mostrar los proveedores
    private void MedTabRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedTabRefreshActionPerformed
        Clear();
        MostrarProv();
    }//GEN-LAST:event_MedTabRefreshActionPerformed

    //Seleccionar los campos de la tabla y subirlos a los campos de texto
    private void ProvTbMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProvTbMousePressed
        DefaultTableModel model = (DefaultTableModel) ProvTb.getModel();
        int indice = ProvTb.getSelectedRow();
        contacto.setText(model.getValueAt(indice, 1).toString());
        direccion.setText(model.getValueAt(indice, 2).toString());
        empresa.setText(model.getValueAt(indice, 3).toString());
        telf.setText(model.getValueAt(indice, 4).toString());
    }//GEN-LAST:event_ProvTbMousePressed

    //Editar el proveedor
    private void ProvEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProvEditActionPerformed
        //Comprobar que los campos mínimos están llenos
        if (empresa.getText().isEmpty() || telf.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce los datos que faltan para poder continuar");
        }
        // Validar que el campo de contacto solo contiene letras si no está vacío
        if (!contacto.getText().trim().isEmpty()) {
            if (!ValidadorDeCadenas.contieneSoloLetras(contacto.getText().trim())) {
                JOptionPane.showMessageDialog(this, "El campo contacto solo debe contener letras");
                return;
            }
        }
        // Validar que el campo de empresa solo contiene letras
        if (!ValidadorDeCadenas.contieneSoloLetras(empresa.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo empresa solo debe contener letras");
            return;
        }

        // Validar que el campo de dirección cumple los requisitos
        if (!direccion.getText().trim().isEmpty()) {
            if (!ValidadorDeDireccion.esDireccionValida(direccion.getText().trim())) {
                JOptionPane.showMessageDialog(this, "El campo dirección solo debe contener letras y números");
                return;
            }
        }
        //Comprobar que el teléfono cumple con las especificaciones
        if (!esValido(telf.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El teléfono debe tener entre 9 y 12 dígitos y no contener caracteres que no sean números.");
            return;
        }

        //Comprobación
        int opcion = JOptionPane.showOptionDialog(
                null,
                "¿Quieres continuar?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new Object[]{"Continuar", "Cancelar"},
                "Continuar");

        if (opcion == JOptionPane.YES_OPTION) {
            try {
                String update = "UPDATE proveedores SET contacto= ?, direccion=?, telefono=? WHERE Idproveedor =(SELECT idProveedor FROM (SELECT * FROM proveedores) AS p WHERE p.empresa = ?);";
                PreparedStatement sentencia = conexion.prepareStatement(update);
                sentencia.setString(1, contacto.getText().trim());
                sentencia.setString(2, direccion.getText().trim());
                sentencia.setString(3, telf.getText().trim());
                sentencia.setString(4, empresa.getText().trim());
                int row = sentencia.executeUpdate();
                JOptionPane.showMessageDialog(this, "Proveedor actualizado correctamente");
                MostrarProv();
                Clear();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());
            }
        } else if (opcion == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "La operación ha sido cancelada");
        }
    }//GEN-LAST:event_ProvEditActionPerformed

    //Consultar proveedores de la base de datos
    private void GestConsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GestConsActionPerformed
        //Comprobar que se han introducido datos de busqueda
        if (empresa.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce la empresa a consultar");
            return;
        }
        // Validar que el campo de empresa solo contiene letras
        if (!empresa.getText().trim().isEmpty()) {
            if (!ValidadorDeCadenas.contieneSoloLetras(empresa.getText().trim())) {
                JOptionPane.showMessageDialog(this, "El campo empresa solo debe contener letras");
                return;
            }
        }
        try {
            String consulta = "SELECT * FROM proveedores WHERE empresa LIKE ?";
            PreparedStatement pstm = conexion.prepareStatement(consulta);
            pstm.setString(1, empresa.getText().trim() + "%");
            ResultSet rs = pstm.executeQuery();

            if (rs.next()) {
                DefaultTableModel model = (DefaultTableModel) ProvTb.getModel();
                model.setRowCount(0); // clear previous data
                rs.beforeFirst();
                while (rs.next()) {
                    Object[] row = new Object[5];
                    row[0] = rs.getString("idProveedor");
                    row[1] = rs.getString("contacto");
                    row[2] = rs.getString("direccion");
                    row[3] = rs.getString("empresa");
                    row[4] = rs.getString("telefono");
                    model.addRow(row);
                }

            } else {
                JOptionPane.showMessageDialog(this, "No se encontraron resultados");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + e.getMessage());
        }
    }//GEN-LAST:event_GestConsActionPerformed

    private void minimizarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizarMousePressed
        this.setState(this.ICONIFIED);
    }//GEN-LAST:event_minimizarMousePressed

    //Cambiar de usuario
    private void logOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logOutActionPerformed
        JOptionPane.showMessageDialog(this, "Se ha cerrado la sesión  del usuario " + Login.loggedInUser);
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logOutActionPerformed

    private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
        initialClick = evt.getPoint();
    }//GEN-LAST:event_jPanel1MousePressed

    private void jPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseDragged
        int thisX = frame.getLocation().x;
        int thisY = frame.getLocation().y;

        int xMoved = evt.getX() - initialClick.x;
        int yMoved = evt.getY() - initialClick.y;

        int X = thisX + xMoved;
        int Y = thisY + yMoved;

        frame.setLocation(X, Y);
    }//GEN-LAST:event_jPanel1MouseDragged

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Proveedores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BrandProv;
    private javax.swing.JButton GestCons;
    private javax.swing.JLabel LogoProv;
    private javax.swing.JLabel MedCant1;
    private javax.swing.JButton MedTabRefresh;
    private javax.swing.JButton ProvAdd;
    private javax.swing.JButton ProvDel;
    private javax.swing.JLabel ProvDir;
    private javax.swing.JButton ProvEdit;
    private javax.swing.JLabel ProvEmp;
    private javax.swing.JLabel ProvListTitle;
    private javax.swing.JLabel ProvMenuGest;
    private javax.swing.JLabel ProvMenuMed;
    private javax.swing.JLabel ProvMenuVtas;
    private javax.swing.JLabel ProvName;
    private javax.swing.JTable ProvTb;
    private javax.swing.JLabel ProvTitle;
    private javax.swing.JLabel ProvTlf;
    private javax.swing.JLabel ProvX;
    private javax.swing.JTextField contacto;
    private javax.swing.JTextField direccion;
    private javax.swing.JTextField empresa;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logOut;
    private javax.swing.JLabel minimizar;
    private javax.swing.JTextField telf;
    private javax.swing.JLabel usuario;
    // End of variables declaration//GEN-END:variables
}
