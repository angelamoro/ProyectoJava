package farmaciacurasana;

import java.awt.Point;
import java.sql.*;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import misClases.Conexion;
import net.proteanit.sql.DbUtils;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import misClases.ComprobarStock;
import misClases.Redondeador;
import misClases.RestaurarStock;
import misClases.ValidadorDeCadenas;
import misClases.ValidadorDeMedicamentos;
import misClases.ImprimePDF;
import static misClases.Redondeador.redondear;

public class Ventas extends javax.swing.JFrame {

    //Declaro las variables a utilizar
    public static Connection conexion;
    public static Statement st = null;
    public static ResultSet rs = null;
    java.util.Date FabDate, ExpDate;
    java.sql.Date myFabDate, myExpDate;
    private static int id, cantidad, stock;
    private static String nombre, proveedor;
    private static double precio, total, totalFact;
    private static String codVenta;
    private static LocalDate dia;
    private static int idVenta;
    private static Point initialClick;
    private JFrame frame;

    private static final String letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final int longitudLetras = letras.length();
    private static final int longitudNumeros = 100;

    public Ventas() {
        initComponents();
        //Abro la conexion
        try {
            conexion = Conexion.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexión con la base de datos.");
            System.exit(0);
        }
        //Cambiar el icono
        setIconImage(new ImageIcon(getClass().getResource("../Images/logo .png")).getImage());
        MostrarMed();
        usuario.setText(Login.loggedInUser);
        totalFacturaTxt.setText("0.0");
        //Desplazar ventana
        jPanel1 = new JPanel();
        frame = this;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        BrandMed = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        LogoMed = new javax.swing.JLabel();
        VtasMenuProv = new javax.swing.JLabel();
        VtasMenuGest = new javax.swing.JLabel();
        MedMenuVtas = new javax.swing.JLabel();
        MedCant1 = new javax.swing.JLabel();
        usuario = new javax.swing.JLabel();
        logOut = new javax.swing.JButton();
        VentasTitle = new javax.swing.JLabel();
        MedName = new javax.swing.JLabel();
        MedCant = new javax.swing.JLabel();
        MedNameTxt = new javax.swing.JTextField();
        MedCantTxt = new javax.swing.JTextField();
        MedAdd = new javax.swing.JButton();
        MedDel = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        MedTb = new javax.swing.JTable();
        MedListTitle = new javax.swing.JLabel();
        vtasX = new javax.swing.JLabel();
        MedCons = new javax.swing.JButton();
        MedTabRefresh = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        facturaTb = new javax.swing.JTable();
        MedListTitle1 = new javax.swing.JLabel();
        imprimir = new javax.swing.JButton();
        minimizar = new javax.swing.JLabel();
        MedCant2 = new javax.swing.JLabel();
        totalFacturaTxt = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel1MouseDragged(evt);
            }
        });
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 153, 255));

        BrandMed.setFont(new java.awt.Font("Dubai", 1, 36)); // NOI18N
        BrandMed.setForeground(new java.awt.Color(255, 255, 255));
        BrandMed.setText("Cura Sana");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        LogoMed.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logo .png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LogoMed)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LogoMed)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        VtasMenuProv.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        VtasMenuProv.setForeground(new java.awt.Color(255, 255, 255));
        VtasMenuProv.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        VtasMenuProv.setText("Proveedores");
        VtasMenuProv.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                VtasMenuProvMousePressed(evt);
            }
        });

        VtasMenuGest.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        VtasMenuGest.setForeground(new java.awt.Color(255, 255, 255));
        VtasMenuGest.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        VtasMenuGest.setText("Empleados");
        VtasMenuGest.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                VtasMenuGestMousePressed(evt);
            }
        });

        MedMenuVtas.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        MedMenuVtas.setForeground(new java.awt.Color(255, 255, 255));
        MedMenuVtas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedMenuVtas.setText("Almacen");
        MedMenuVtas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MedMenuVtasMousePressed(evt);
            }
        });

        MedCant1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedCant1.setForeground(new java.awt.Color(255, 255, 255));
        MedCant1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedCant1.setText("Usuario:");

        usuario.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        usuario.setForeground(new java.awt.Color(255, 255, 255));
        usuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        usuario.setText("usuario");

        logOut.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        logOut.setText("Salir");
        logOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logOutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(VtasMenuGest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(BrandMed)))
                        .addGap(0, 13, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(MedCant1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(usuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(VtasMenuProv, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(MedMenuVtas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(logOut)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BrandMed)
                .addGap(39, 39, 39)
                .addComponent(VtasMenuGest)
                .addGap(18, 18, 18)
                .addComponent(VtasMenuProv)
                .addGap(18, 18, 18)
                .addComponent(MedMenuVtas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 194, Short.MAX_VALUE)
                .addComponent(MedCant1)
                .addGap(18, 18, 18)
                .addComponent(usuario)
                .addGap(18, 18, 18)
                .addComponent(logOut, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );

        VentasTitle.setFont(new java.awt.Font("Dubai", 1, 36)); // NOI18N
        VentasTitle.setForeground(new java.awt.Color(0, 0, 0));
        VentasTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        VentasTitle.setText("Ventas");

        MedName.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedName.setForeground(new java.awt.Color(0, 0, 0));
        MedName.setText("Nombre:");

        MedCant.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedCant.setForeground(new java.awt.Color(0, 0, 0));
        MedCant.setText("Cantidad:");

        MedAdd.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedAdd.setText("Añadir");
        MedAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedAddActionPerformed(evt);
            }
        });

        MedDel.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedDel.setText("Eliminar");
        MedDel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedDelActionPerformed(evt);
            }
        });

        MedTb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Precio", "Stock", "Proveedor"
            }
        ));
        MedTb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MedTbMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(MedTb);

        MedListTitle.setFont(new java.awt.Font("Dubai", 0, 24)); // NOI18N
        MedListTitle.setForeground(new java.awt.Color(0, 0, 0));
        MedListTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedListTitle.setText("Listado de medicamentos");

        vtasX.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        vtasX.setForeground(new java.awt.Color(0, 153, 255));
        vtasX.setText("X");
        vtasX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                vtasXMousePressed(evt);
            }
        });

        MedCons.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedCons.setText("Consultar");
        MedCons.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedConsActionPerformed(evt);
            }
        });

        MedTabRefresh.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedTabRefresh.setText("Refrescar");
        MedTabRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedTabRefreshActionPerformed(evt);
            }
        });

        facturaTb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre", "PVP", "Cantidad", "Total"
            }
        ));
        facturaTb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                facturaTbMousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(facturaTb);

        MedListTitle1.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        MedListTitle1.setForeground(new java.awt.Color(0, 0, 0));
        MedListTitle1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedListTitle1.setText("Factura");

        imprimir.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        imprimir.setText("Facturar");
        imprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imprimirActionPerformed(evt);
            }
        });

        minimizar.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        minimizar.setForeground(new java.awt.Color(0, 153, 255));
        minimizar.setText("-");
        minimizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                minimizarMousePressed(evt);
            }
        });

        MedCant2.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedCant2.setForeground(new java.awt.Color(0, 0, 0));
        MedCant2.setText("Total:");

        totalFacturaTxt.setEditable(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(MedName, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(MedNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(MedCant, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(MedCantTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(39, 39, 39)
                                        .addComponent(MedCons, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(25, 25, 25)
                                        .addComponent(MedTabRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(42, 42, 42)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 464, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(206, 206, 206)
                                .addComponent(MedAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)
                                .addComponent(MedDel, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(imprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(351, 351, 351)
                                .addComponent(MedListTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 464, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(VentasTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(minimizar)
                                .addGap(18, 18, 18)
                                .addComponent(vtasX)))
                        .addGap(21, 21, 21))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(MedCant2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(totalFacturaTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 804, Short.MAX_VALUE)
                            .addComponent(MedListTitle1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(32, 32, 32))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(VentasTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(vtasX)
                            .addComponent(minimizar))))
                .addGap(27, 27, 27)
                .addComponent(MedListTitle)
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(MedName)
                            .addComponent(MedNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(MedCant)
                            .addComponent(MedCantTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(MedCons)
                            .addComponent(MedTabRefresh)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MedAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(MedDel, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(imprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(MedListTitle1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(totalFacturaTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(MedCant2))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    //Mostrar la tabla de los medicamentos
    public void MostrarMed() {
        try {
            st = conexion.createStatement();
            rs = st.executeQuery("SELECT m.Id, m.Nombre, m.Pvp, m.stock, p.Empresa FROM medicamentos m INNER JOIN proveedores p ON m.idProveedor = p.IdProveedor ORDER BY m.nombre;");
            MedTb.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + e.getMessage());
        }
    }

    //Borrar lo seleccionado o escrito
    public void Clear() {
        MedNameTxt.setText("");
        MedCantTxt.setText("");
        MostrarMed();
    }

    //Comprobar si la tabla factura contiene elementos
    private boolean isFacturaTableEmpty() {
        DefaultTableModel model = (DefaultTableModel) facturaTb.getModel();
        return model.getRowCount() == 0;
    }

    //Devuelve el stock a su original al no realizar una venta después de añadir medicamentos a la tabla factura
    private void restaurarStockTablaFactura() {
        DefaultTableModel model = (DefaultTableModel) facturaTb.getModel();
        int rowCount = model.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            String nombre = model.getValueAt(i, 1).toString();
            int cantidad = Integer.parseInt(model.getValueAt(i, 3).toString());
            RestaurarStock rs = new RestaurarStock(nombre, cantidad);
            rs.restaurarStock();
        }
    }

    //Cerrar el programa y la conexión
    private void vtasXMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vtasXMousePressed
        //Aumentar de nuevo el stock a su original de  los productos no vendidos de la tabla factura
        if (!isFacturaTableEmpty()) {
            System.out.println("La tabla factura no está vacía");
            //Aumentar de nuevo el stock a su original de los productos no vendidos de la tabla factura
            restaurarStockTablaFactura();

        }
        try {
            // Cerrar el objeto Statement
            if (st != null) {
                st.close();
            }
            // Cerrar la conexión a la base de datos
            if (conexion != null) {
                Conexion.closeConnection();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ex.getMessage();
        }
        dispose();//Cierra la pantalla          
    }//GEN-LAST:event_vtasXMousePressed

    //Cambiar a la pantalla de medicamentos (almacen)
    private void MedMenuVtasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MedMenuVtasMousePressed
        //Aumentar de nuevo el stock a su original de  los productos no vendidos de la tabla factura
        if (!isFacturaTableEmpty()) {
            System.out.println("La tabla factura no está vacía");
            //Aumentar de nuevo el stock a su original de los productos no vendidos de la tabla factura
            restaurarStockTablaFactura();

        }
        new Medicamentos().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_MedMenuVtasMousePressed

//Minimizar el programa
    private void minimizarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizarMousePressed
        this.setState(this.ICONIFIED);
    }//GEN-LAST:event_minimizarMousePressed

    //Cambiar al gestor de empleados
    private void VtasMenuGestMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VtasMenuGestMousePressed
        //Aumentar de nuevo el stock a su original de  los productos no vendidos de la tabla factura
        if (!isFacturaTableEmpty()) {
            System.out.println("La tabla factura no está vacía");
            //Aumentar de nuevo el stock a su original de los productos no vendidos de la tabla factura
            restaurarStockTablaFactura();

        }
        new Empleados().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_VtasMenuGestMousePressed

    //Cambiar al gestor de proveedores
    private void VtasMenuProvMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VtasMenuProvMousePressed
        //Aumentar de nuevo el stock a su original de  los productos no vendidos de la tabla factura
        if (!isFacturaTableEmpty()) {
            System.out.println("La tabla factura no está vacía");
            //Aumentar de nuevo el stock a su original de los productos no vendidos de la tabla factura
            restaurarStockTablaFactura();

        }
        new Proveedores().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_VtasMenuProvMousePressed

    //Botón refrescar
    private void MedTabRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedTabRefreshActionPerformed
        Clear();
    }//GEN-LAST:event_MedTabRefreshActionPerformed

    //Botón consulta
    private void MedConsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedConsActionPerformed
        if (MedNameTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce el nombre del medicamento a consultar");
            return;
        }
        //Validar el nombre del medicamento
        if (!ValidadorDeCadenas.contieneLetrasyNumeros(MedNameTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo nombre solo puede contener letras y números");
            return;
        }
        //Muestra los datos del medicamento
        try {
            String consulta = "SELECT m.id, m.Nombre, m.Pvp, m.stock, p.Empresa FROM medicamentos m INNER JOIN proveedores p ON m.idProveedor = p.IdProveedor WHERE Nombre LIKE ?";
            PreparedStatement pstm = conexion.prepareStatement(consulta);
            pstm.setString(1, MedNameTxt.getText().trim() + "%");
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                DefaultTableModel model = (DefaultTableModel) MedTb.getModel();
                model.setRowCount(0); // clear previous data
                rs.beforeFirst();
                while (rs.next()) {
                    Object[] row = new Object[7];
                    row[0] = rs.getString("id");
                    row[1] = rs.getString("nombre");
                    row[2] = rs.getString("pvp");
                    row[3] = rs.getString("stock");
                    row[4] = rs.getString("empresa");
                    model.addRow(row);
                }
            } else {
                JOptionPane.showMessageDialog(this, "No se encontraron resultados");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + e.getMessage());
        }
    }//GEN-LAST:event_MedConsActionPerformed

    //Selección de elementos de la tabla de medicamentos
    private void MedTbMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MedTbMousePressed
        DefaultTableModel model = (DefaultTableModel) MedTb.getModel();
        int indice = MedTb.getSelectedRow();
        if (indice >= 0) { // Comprueba si alguna fila está seleccionada
            id = Integer.parseInt(model.getValueAt(indice, 0).toString());
            nombre = model.getValueAt(indice, 1).toString();
            precio = Double.parseDouble(model.getValueAt(indice, 2).toString());
            stock = Integer.parseInt(model.getValueAt(indice, 3).toString());
            MedNameTxt.setText(nombre);
            System.out.println(id + ", " + nombre + ", " + precio + ", " + stock);//Controla que guarda bien las variales seleccionadas en la tabla
        }
    }//GEN-LAST:event_MedTbMousePressed

//Calculo del coste total de los medicamentos en la tabla factura
    private double setTotalFactura() {
        double totalFactura = 0.0;
        DefaultTableModel facturaModel = (DefaultTableModel) facturaTb.getModel();
        for (int i = 0; i < facturaModel.getRowCount(); i++) {
            String totalStr = String.valueOf(facturaModel.getValueAt(i, 4)).replace(",", ".");
            double total = Double.parseDouble(totalStr);
            totalFactura += Redondeador.redondear(total, 2);
        }
        return totalFactura;
    }

    //Disminuir el stock del medicamento vendido
    public void dismStock() {
        if (MedCantTxt.getText().isEmpty() && MedNameTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce el nombre y la cantidad del medicamento a vender");
        } else {
            try {
                String consulta = "UPDATE Medicamentos SET stock = stock - ? WHERE nombre = ?";
                PreparedStatement actualizacion = conexion.prepareStatement(consulta);
                actualizacion.setInt(1, Integer.valueOf(MedCantTxt.getText().trim()));
                actualizacion.setString(2, MedNameTxt.getText().trim());
                actualizacion.executeUpdate();
                MostrarMed();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + ex.getMessage());
            }
        }
    }

//Añadir medicamentos a la tabla facturas
    private void MedAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedAddActionPerformed
        //Comprobar que los datos requeridos no están vacíos
        if (MedNameTxt.getText().isEmpty() || MedCantTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce el nombre del medicamento y una cantidad superior a 0 para proceder a la venta");
        }
        //Validar el nombre del medicamento
        if (!ValidadorDeCadenas.contieneLetrasyNumeros(MedNameTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo nombre solo puede contener letras y números");
            return;
        }

        //Comprobar si el medicamento existe
        ValidadorDeMedicamentos comprobador = new ValidadorDeMedicamentos(conexion);
        boolean existeMedicamento = true;

        try {
            existeMedicamento = comprobador.existeMedicamento(MedNameTxt.getText().trim());
        } catch (SQLException ex) {
            Logger.getLogger(Medicamentos.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (!existeMedicamento) {
            JOptionPane.showMessageDialog(this, "No existe un medicamento con ese nombre");
            return;
        }

        //Validar que la cantidad introducida es un numero positivo mayor que cero
        String numero = MedCantTxt.getText().trim();
        int valor;
        try {
            valor = Integer.parseInt(numero);
            if (valor <= 0) {
                JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor que cero");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un número entero");
            return;
        }

        // Comprobar stock disponible antes de añadir el medicamento a la factura
        ComprobarStock comprobarStock = new ComprobarStock(conexion);
        int stockDisponible = 0;
        try {
            stockDisponible = comprobarStock.hayStock(MedNameTxt.getText().trim(), Integer.parseInt(MedCantTxt.getText().trim()));
            System.out.println("Stock disponible: " + stockDisponible);
        } catch (SQLException ex) {
            Logger.getLogger(Ventas.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (stockDisponible < Integer.parseInt(MedCantTxt.getText())) {
            JOptionPane.showMessageDialog(this, "No hay suficiente stock del medicamento seleccionado");
            return;
        }

        DefaultTableModel facturaModel = (DefaultTableModel) facturaTb.getModel();
        cantidad = Integer.parseInt(MedCantTxt.getText());
        total = Redondeador.redondear((precio * cantidad), 2);

        //Añade una nueva fila a la tabla de factura con los valores de id, nombre, precio, cantidad y total
        Object[] row = {id, nombre, precio, cantidad, total};
        facturaModel.addRow(row);
        dismStock();
        totalFact = redondear(setTotalFactura(), 2);
        totalFacturaTxt.setText(String.valueOf(totalFact));
        Clear();
    }//GEN-LAST:event_MedAddActionPerformed

    //Selección de los elementos de la tabla factura
    private void facturaTbMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_facturaTbMousePressed
        DefaultTableModel model = (DefaultTableModel) facturaTb.getModel();
        int indice = facturaTb.getSelectedRow();
        if (indice >= 0) { // Check if a row is selected
            id = Integer.parseInt(model.getValueAt(indice, 0).toString());
            nombre = model.getValueAt(indice, 1).toString();
            precio = Double.parseDouble(model.getValueAt(indice, 2).toString());
            cantidad = Integer.parseInt(model.getValueAt(indice, 3).toString());
            MedNameTxt.setText(nombre);
            MedCantTxt.setText(model.getValueAt(indice, 3).toString());

            System.out.println("Elemento en factura: " + id + ", " + nombre + ", " + precio + ", " + stock); //Controlo que guarda bien las variales seleccionadas en la tabla
        }
    }//GEN-LAST:event_facturaTbMousePressed

    //Aumenta el stock al eliminar elementos de la facttura
    public void AumStock() {
        if (MedNameTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecciona el medicamento a eliminar de la factura");
        } else {
            try {
                String consulta = "UPDATE Medicamentos SET stock = stock + ? WHERE nombre = ?";
                PreparedStatement actualizacion = conexion.prepareStatement(consulta);
                actualizacion.setInt(1, Integer.valueOf(MedCantTxt.getText().trim()));
                actualizacion.setString(2, MedNameTxt.getText().trim());
                actualizacion.executeUpdate();
                MostrarMed();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + ex.getMessage());
            }
        }
    }

    //Eliminar elementos de la tabla factura
    private void MedDelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedDelActionPerformed
        if (MedNameTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecciona el medicamento a eliminar de la factura");
        } else {
            DefaultTableModel model = (DefaultTableModel) facturaTb.getModel();
            int indice = facturaTb.getSelectedRow();
            if (indice >= 0) { // Check if a row is selected
                model.removeRow(indice);
                AumStock();
                totalFacturaTxt.setText(String.valueOf(setTotalFactura()));
                Clear();
            }
        }
    }//GEN-LAST:event_MedDelActionPerformed

    //Obtener el id de empleado
    private int getIdEmpleado() {
        int id = 0;
        try {
            String consulta = "SELECT IdEmpleado FROM Empleados WHERE usuario = ?";
            PreparedStatement pstm = conexion.prepareStatement(consulta);
            pstm.setString(1, Login.loggedInUser);
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                id = rs.getInt("IdEmpleado");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Algo ha ido mal, revisa los datos introducidos" + ex.getMessage());
        }
        return id;
    }

    //Generar un código aleatorio para las ventas
    public static String generarCodigo() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();

        // Generar dos letras aleatorias
        for (int i = 0; i < 2; i++) {
            char letra = letras.charAt(random.nextInt(longitudLetras));
            sb.append(letra);
        }

        // Generar dos números aleatorios
        for (int i = 0; i < 2; i++) {
            int numero = random.nextInt(longitudNumeros);
            sb.append(String.format("%02d", numero));
        }
        return sb.toString();
    }

    //Insertar los datos en la tabla de ventas
    private void addVenta() {
        int idEmpleado = getIdEmpleado();
        System.out.println("idEmpleado: " + idEmpleado);
        if (idEmpleado == 0) {
            JOptionPane.showMessageDialog(this, "No se ha podido realizar la venta porque ningún empleado ha iniciado sesión");
        } else {

            dia = LocalDate.now();
            codVenta = generarCodigo();
            System.out.println(dia);
            try {
                String consulta = "INSERT INTO Ventas (codVenta, fecha, idEmpleado) VALUES (?, ?, ?)";
                PreparedStatement sentencia = conexion.prepareStatement(consulta);
                sentencia.setString(1, codVenta);
                sentencia.setDate(2, java.sql.Date.valueOf(dia));
                sentencia.setInt(3, idEmpleado);
                int filasAfectadas = sentencia.executeUpdate();
                if (filasAfectadas > 0) {
                    System.out.println("La venta se ha registrado correctamente.");
                } else {
                    System.out.println("No se ha podido registrar la venta.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                System.out.println("Ha ocurrido un error al registrar la venta: " + ex.getMessage());
            }

            System.out.println("Se ha añadido la venta en ventas");
        }
    }

    //Obtener el id de venta para poder introducir los datos en la tabla lineasVenta
    private int getidVenta() {
        try {
            System.out.println("Código de venta: " + codVenta);
            String consulta = "SELECT IdVenta FROM Ventas WHERE codVenta=?";
            PreparedStatement sentencia = conexion.prepareStatement(consulta);
            sentencia.setString(1, codVenta);
            ResultSet resultado = sentencia.executeQuery();

            if (resultado.next()) {
                int idVentaObtenido = resultado.getInt(1);
                System.out.println("Se ha obtenido el id de la venta: " + idVentaObtenido);
                return idVentaObtenido;
            } else {
                System.out.println("No se ha encontrado ninguna venta con el código proporcionado.");
                return -1; // Or any other value that indicates a failure to retrieve the IdVenta.
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Ha ocurrido un error al registrar la venta: " + ex.getMessage());
        }
        return idVenta;
    }

    //Insertar los datos en la tabla lineas de  ventas
    public void insertarLineasVenta(DefaultTableModel modeloTabla, int idVenta) {
        try {
            for (int i = 0; i < modeloTabla.getRowCount(); i++) {
                String consulta = "INSERT INTO lineasVenta (IdMedicamento, pvp, cantidad, total, IdVenta) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement sentencia = conexion.prepareStatement(consulta);
                sentencia.setInt(1, (int) modeloTabla.getValueAt(i, 0));
                sentencia.setDouble(2, (Double) modeloTabla.getValueAt(i, 2));
                sentencia.setInt(3, (int) modeloTabla.getValueAt(i, 3));
                sentencia.setDouble(4, (Double) modeloTabla.getValueAt(i, 4));
                sentencia.setInt(5, idVenta);
                int filasAfectadas = sentencia.executeUpdate();
                if (filasAfectadas > 0) {
                    System.out.println("La línea de venta registrada correctamente.");
                } else {
                    System.out.println("No se ha podido registrar la línea de venta.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Ha ocurrido un error al registrar la línea de venta: " + ex.getMessage());
        }
    }

    //Insertar el total de la factura en la tabla facturacion
    public void insertarFacturacion(DefaultTableModel modeloTabla, int idVenta) {

        try {
            String consulta = "INSERT INTO facturacion (totalFact, IdVenta) VALUES (?, ?)";
            PreparedStatement sentencia = conexion.prepareStatement(consulta);
            sentencia.setDouble(1, totalFact);
            sentencia.setInt(2, idVenta);
            sentencia.executeUpdate();
            System.out.println("Facturación registrada correctamente.");

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Ha ocurrido un error al registrar la facturación: " + ex.getMessage());
        }
    }

    //Imprimir factura y añadir los datos de la venta a la bbdd
    private void imprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imprimirActionPerformed

        DefaultTableModel model = (DefaultTableModel) facturaTb.getModel();
        addVenta(); //Añade la venta
        idVenta = getidVenta(); //Obtiene el id de la venta creada y lo asigna a la variable idVenta
        if (idVenta != -1) {
            insertarLineasVenta(model, idVenta); //Añade la línea de venta
            System.out.println("Se han añadido las lineas de venta");

        } else {
            System.out.println("No se han añadido las líneas de venta debido a un error al obtener el idVenta.");
            JOptionPane.showMessageDialog(this, "No se ha podido generar la factura");
        }
        if (idVenta == 0) {

        } else {
            insertarFacturacion(model, idVenta);
            DefaultTableModel modeloTabla = (DefaultTableModel) facturaTb.getModel();
            String nombreFact = "Factura" + dia + codVenta + ".pdf";
            ImprimePDF.generaPDF("src/PDFs/" + nombreFact, dia, totalFact, facturaTb);
            JOptionPane.showMessageDialog(this, nombreFact + " generada correctamente");
            modeloTabla.setRowCount(0);
            Clear();
            totalFacturaTxt.setText("0.0");
        }
    }//GEN-LAST:event_imprimirActionPerformed

    //Cambiar de usuario
    private void logOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logOutActionPerformed
        if (!isFacturaTableEmpty()) {
            System.out.println("La tabla factura no está vacía");
            //Aumentar de nuevo el stock a su original de los productos no vendidos de la tabla factura
            restaurarStockTablaFactura();
        }
        JOptionPane.showMessageDialog(this, "Se ha cerrado la sesión  del usuario " + Login.loggedInUser);
        new Login().setVisible(true);

        this.dispose();
    }//GEN-LAST:event_logOutActionPerformed

    //Arrastrar ventana
    private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
        initialClick = evt.getPoint();
    }//GEN-LAST:event_jPanel1MousePressed

    private void jPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseDragged
        int thisX = frame.getLocation().x;
        int thisY = frame.getLocation().y;

        int xMoved = evt.getX() - initialClick.x;
        int yMoved = evt.getY() - initialClick.y;

        int X = thisX + xMoved;
        int Y = thisY + yMoved;

        frame.setLocation(X, Y);
    }//GEN-LAST:event_jPanel1MouseDragged

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BrandMed;
    private javax.swing.JLabel LogoMed;
    private javax.swing.JButton MedAdd;
    private javax.swing.JLabel MedCant;
    private javax.swing.JLabel MedCant1;
    private javax.swing.JLabel MedCant2;
    private javax.swing.JTextField MedCantTxt;
    private javax.swing.JButton MedCons;
    private javax.swing.JButton MedDel;
    private javax.swing.JLabel MedListTitle;
    private javax.swing.JLabel MedListTitle1;
    private javax.swing.JLabel MedMenuVtas;
    private javax.swing.JLabel MedName;
    private javax.swing.JTextField MedNameTxt;
    private javax.swing.JButton MedTabRefresh;
    private javax.swing.JTable MedTb;
    private javax.swing.JLabel VentasTitle;
    private javax.swing.JLabel VtasMenuGest;
    private javax.swing.JLabel VtasMenuProv;
    private javax.swing.JTable facturaTb;
    private javax.swing.JButton imprimir;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton logOut;
    private javax.swing.JLabel minimizar;
    private javax.swing.JTextField totalFacturaTxt;
    private javax.swing.JLabel usuario;
    private javax.swing.JLabel vtasX;
    // End of variables declaration//GEN-END:variables
}
