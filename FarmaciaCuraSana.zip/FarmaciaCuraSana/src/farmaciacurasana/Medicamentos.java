package farmaciacurasana;

import java.awt.Point;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import static misClases.ComprobadorNumeros.*;
import misClases.ComprobarFecha;
import misClases.Conexion;
import misClases.ValidadorDeCadenas;
import misClases.ValidadorDeMedicamentos;
import net.proteanit.sql.DbUtils;

/*El paquete dbutils de Java proporciona una serie de clases y utilidades para simplificar el acceso a bases de datos y reducir la cantidad de código 
necesario para realizar operaciones comunes en bases de datos relacionales.
rs2xml.jar es una librería que se puede utilizar en NetBeans para visualizar los resultados de una consulta SQL en una tabla
 */
public class Medicamentos extends javax.swing.JFrame {

    public Medicamentos() {
        initComponents();
        //Abro la conexion
        try {
            conexion = Conexion.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexión con la base de datos.");
            System.exit(0);
        }
        //Cambiar el icono
        setIconImage(new ImageIcon(getClass().getResource("../Images/logo .png")).getImage());
        MostrarMed();
        GetProv();
        usuario.setText(Login.loggedInUser);
        //Desplazar ventana
        jPanel1 = new JPanel();
        frame = this;
    }

    public static Connection conexion;
    public static Statement st = null;
    public static ResultSet rs = null;
    private static Point initialClick;
    private JFrame frame;
    java.util.Date FabDate, ExpDate;
    java.sql.Date myFabDate, myExpDate;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        BrandMed = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        LogoMed = new javax.swing.JLabel();
        MenuProveedores = new javax.swing.JLabel();
        MenuEmpleados = new javax.swing.JLabel();
        MedMenuVtas = new javax.swing.JLabel();
        usuario = new javax.swing.JLabel();
        MedCant1 = new javax.swing.JLabel();
        logOut = new javax.swing.JButton();
        MedicamentosTitle = new javax.swing.JLabel();
        MedName = new javax.swing.JLabel();
        MedPrice = new javax.swing.JLabel();
        MedCant = new javax.swing.JLabel();
        MedFab = new javax.swing.JLabel();
        MedCad = new javax.swing.JLabel();
        MedProv = new javax.swing.JLabel();
        MedNameTxt = new javax.swing.JTextField();
        MedCantTxt = new javax.swing.JTextField();
        MedPriceTxt = new javax.swing.JTextField();
        MedProvSel = new javax.swing.JComboBox<>();
        MedFabDate = new com.toedter.calendar.JDateChooser();
        MedCadDate = new com.toedter.calendar.JDateChooser();
        MedAdd = new javax.swing.JButton();
        MedEdit = new javax.swing.JButton();
        MedTabRefresh = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        MedTb = new javax.swing.JTable();
        MedListTitle = new javax.swing.JLabel();
        MedX = new javax.swing.JLabel();
        MedCons = new javax.swing.JButton();
        MedDel = new javax.swing.JButton();
        minimizar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel1MouseDragged(evt);
            }
        });
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 153, 255));

        BrandMed.setFont(new java.awt.Font("Dubai", 1, 36)); // NOI18N
        BrandMed.setForeground(new java.awt.Color(255, 255, 255));
        BrandMed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BrandMed.setText("Cura Sana");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        LogoMed.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logo .png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LogoMed)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LogoMed)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        MenuProveedores.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        MenuProveedores.setForeground(new java.awt.Color(255, 255, 255));
        MenuProveedores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MenuProveedores.setText("Proveedores");
        MenuProveedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MenuProveedoresMousePressed(evt);
            }
        });

        MenuEmpleados.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        MenuEmpleados.setForeground(new java.awt.Color(255, 255, 255));
        MenuEmpleados.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MenuEmpleados.setText("Empleados");
        MenuEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MenuEmpleadosMousePressed(evt);
            }
        });

        MedMenuVtas.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        MedMenuVtas.setForeground(new java.awt.Color(255, 255, 255));
        MedMenuVtas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedMenuVtas.setText("Ventas");
        MedMenuVtas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MedMenuVtasMousePressed(evt);
            }
        });

        usuario.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        usuario.setForeground(new java.awt.Color(255, 255, 255));
        usuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        usuario.setText("usuario");

        MedCant1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedCant1.setForeground(new java.awt.Color(255, 255, 255));
        MedCant1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedCant1.setText("Usuario:");

        logOut.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        logOut.setText("Salir");
        logOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logOutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BrandMed, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(MedCant1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(usuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(MenuEmpleados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 35, Short.MAX_VALUE))
                    .addComponent(MedMenuVtas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(MenuProveedores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(logOut)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BrandMed)
                .addGap(41, 41, 41)
                .addComponent(MenuEmpleados)
                .addGap(18, 18, 18)
                .addComponent(MenuProveedores)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(MedMenuVtas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 188, Short.MAX_VALUE)
                .addComponent(MedCant1)
                .addGap(18, 18, 18)
                .addComponent(usuario)
                .addGap(18, 18, 18)
                .addComponent(logOut, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43))
        );

        MedicamentosTitle.setFont(new java.awt.Font("Dubai", 1, 36)); // NOI18N
        MedicamentosTitle.setForeground(new java.awt.Color(0, 0, 0));
        MedicamentosTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedicamentosTitle.setText("Almacen");

        MedName.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedName.setForeground(new java.awt.Color(0, 0, 0));
        MedName.setText("Nombre:");

        MedPrice.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedPrice.setForeground(new java.awt.Color(0, 0, 0));
        MedPrice.setText("PVP:");

        MedCant.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedCant.setForeground(new java.awt.Color(0, 0, 0));
        MedCant.setText("Stock:");

        MedFab.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedFab.setForeground(new java.awt.Color(0, 0, 0));
        MedFab.setText("Fabricación:");

        MedCad.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedCad.setForeground(new java.awt.Color(0, 0, 0));
        MedCad.setText("Caducidad:");

        MedProv.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedProv.setForeground(new java.awt.Color(0, 0, 0));
        MedProv.setText("Proveedor:");

        MedAdd.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedAdd.setText("Añadir");
        MedAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedAddActionPerformed(evt);
            }
        });

        MedEdit.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedEdit.setText("Actualizar");
        MedEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedEditActionPerformed(evt);
            }
        });

        MedTabRefresh.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedTabRefresh.setText("Refrescar");
        MedTabRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedTabRefreshActionPerformed(evt);
            }
        });

        MedTb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Precio", "Cantidad", "Fabricación", "Caducidad", "Proveedor"
            }
        ));
        MedTb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MedTbMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(MedTb);

        MedListTitle.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        MedListTitle.setForeground(new java.awt.Color(0, 0, 0));
        MedListTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedListTitle.setText("Listado de medicamentos");

        MedX.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        MedX.setForeground(new java.awt.Color(0, 153, 255));
        MedX.setText("X");
        MedX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                MedXMousePressed(evt);
            }
        });

        MedCons.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedCons.setText("Consultar");
        MedCons.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedConsActionPerformed(evt);
            }
        });

        MedDel.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        MedDel.setText("Eliminar");
        MedDel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedDelActionPerformed(evt);
            }
        });

        minimizar.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        minimizar.setForeground(new java.awt.Color(0, 153, 255));
        minimizar.setText("-");
        minimizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                minimizarMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(MedName, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(MedNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(MedPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(MedPriceTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(MedCant, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(MedCantTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(79, 79, 79)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(MedProv)
                                        .addGap(21, 21, 21)
                                        .addComponent(MedProvSel, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(MedCad)
                                            .addComponent(MedFab))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(MedCadDate, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(MedFabDate, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(MedicamentosTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(minimizar)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addComponent(MedX)
                        .addGap(28, 28, 28))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(82, 82, 82)
                                    .addComponent(MedCons, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(39, 39, 39)
                                    .addComponent(MedAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(32, 32, 32)
                                    .addComponent(MedEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(41, 41, 41)
                                    .addComponent(MedDel, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(41, 41, 41))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addGap(63, 63, 63)
                                    .addComponent(MedListTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(65, 65, 65)
                                    .addComponent(MedTabRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 715, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                                .addComponent(MedicamentosTitle)
                                .addGap(26, 26, 26))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(minimizar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(MedFab)
                                    .addComponent(MedFabDate, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(22, 22, 22)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(MedCad)
                                    .addComponent(MedCadDate, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(MedProvSel, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MedProv)
                                    .addComponent(MedCantTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MedCant)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(MedName)
                                    .addGap(24, 24, 24))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(MedNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(22, 22, 22)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(MedPriceTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(MedPrice)))))
                        .addGap(55, 55, 55))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(MedX)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MedAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(MedEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(MedCons, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(MedDel, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MedTabRefresh)
                    .addComponent(MedListTitle))
                .addGap(14, 14, 14)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 44, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    //Mostrar los medicamentos almaenados en la base de datos
    public void MostrarMed() {
        try {
            st = conexion.createStatement();
            rs = st.executeQuery("SELECT m.Id, m.Nombre, m.Pvp, m.stock, m.Fabricacion, m.Caducidad, p.Empresa FROM medicamentos m INNER JOIN proveedores p ON m.idProveedor = p.IdProveedor ORDER BY m.Nombre;");
            MedTb.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + e.getMessage());
        }
    }

    //Vaciar los campos de display
    public void Clear() {
        MedNameTxt.setText("");
        MedPriceTxt.setText("");
        MedCantTxt.setText("");
        //Pone el jchosser en la fecha actual
        MedFabDate.setDate(Calendar.getInstance().getTime());
        MedCadDate.setDate(Calendar.getInstance().getTime());
        //Vaciar el selector
        MedProvSel.setSelectedItem(null);
    }

    //Obtener la lista de proveedores
    public void GetProv() {
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(" SELECT * FROM Proveedores");
            while (rs.next()) {
                String myProv = rs.getString("Empresa");
                MedProvSel.addItem(myProv);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + e.getMessage());
        }
    }

//Cerrar la pantalla
    private void MedXMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MedXMousePressed
        try {
            // Cerrar el objeto Statement
            if (st != null) {
                st.close();
            }
            // Cerrar la conexión a la base de datos
            if (conexion != null) {
                Conexion.closeConnection();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        dispose();//Cierra la pantalla                              
    }//GEN-LAST:event_MedXMousePressed

    //Añadir medicamentos
    private void MedAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedAddActionPerformed
        //Comprobar que se introducen los datos requeridos
        if (MedNameTxt.getText().isEmpty() || MedPriceTxt.getText().isEmpty() || MedCantTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce los datos que faltan para poder continuar");
        }
        //Validar el nombre del medicamento
        if (!ValidadorDeCadenas.contieneLetrasyNumeros(MedNameTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo nombre solo puede contener letras y números");
            return;
        }
        //Comprobar si el medicamento ya existe
        ValidadorDeMedicamentos comprobador = new ValidadorDeMedicamentos(conexion);
        try {
            if (comprobador.existeMedicamento(MedNameTxt.getText().trim())) {
                JOptionPane.showMessageDialog(this, "Ya existe un medicamento con ese nombre");
                return;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Medicamentos.class.getName()).log(Level.SEVERE, null, ex);
        }
        //Comprobar que se introduce un número decimal en el precio
        if (!esNumeroDecimal(MedPriceTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo precio solo puede contener números enteros o números decimales (no utilizar coma)");
            return;
        }
        //Comprobar que se introduce un número entero en stock
        if (!esNumero(MedCantTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo stock solo puede contener números enteros");
            return;
        }

        // Validar que la fecha seleccionada no es posterior a la fecha actual
        if (ComprobarFecha.esFechaPosterior(MedFabDate.getDate())) {
            JOptionPane.showMessageDialog(this, "La fecha de fabricación no puede ser posterior a la fecha actual");
            return;
        }

        if (MedProvSel.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un proveedor");
            return;

        } else {
            //Comprobación
            int opcion = JOptionPane.showOptionDialog(
                    null,
                    "¿Quieres continuar?",
                    "Confirmación",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    new Object[]{"Continuar", "Cancelar"},
                    "Continuar");

            if (opcion == JOptionPane.YES_OPTION) {
                //Realizar la consulta
                try {
                    //Almacenar las fechas de fabricación y caducidad
                    FabDate = MedFabDate.getDate();
                    ExpDate = MedCadDate.getDate();
                    myFabDate = new java.sql.Date(FabDate.getTime());
                    myExpDate = new java.sql.Date(ExpDate.getTime());

                    //Realizar la consulta
                    String consulta = " INSERT INTO Medicamentos (Nombre, pvp, stock, Fabricacion, Caducidad, idProveedor) values (?, ?, ?, ?, ?, (select idproveedor FROM Proveedores WHERE Empresa = ?)) ";
                    PreparedStatement sentencia = conexion.prepareStatement(consulta);
                    sentencia.setString(1, MedNameTxt.getText().trim());
                    sentencia.setDouble(2, Double.valueOf(MedPriceTxt.getText().trim()));
                    sentencia.setInt(3, Integer.valueOf(MedCantTxt.getText().trim()));
                    sentencia.setDate(4, myFabDate);
                    sentencia.setDate(5, myExpDate);
                    sentencia.setString(6, MedProvSel.getSelectedItem().toString());
                    int row = sentencia.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Medicamento añadido correctamente");
                    MostrarMed();
                    Clear();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());
                }
            } else if (opcion == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, "La operación ha sido cancelada");
            }
        }
    }//GEN-LAST:event_MedAddActionPerformed

    //Eliminar medicamento
    private void MedDelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedDelActionPerformed
        //Comprobar que el campo no está vacío
        if (MedNameTxt.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce el nombre del medicamento a eliminar");
            return;
        }

        //Validar el nombre del medicamento
        if (!ValidadorDeCadenas.contieneLetrasyNumeros(MedNameTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo nombre solo puede contener letras y números");
            return;
        }

        //Comprobar si el medicamento existe
        ValidadorDeMedicamentos comprobador = new ValidadorDeMedicamentos(conexion);
        boolean existeMedicamento = true;
        try {
            existeMedicamento = comprobador.existeMedicamento(MedNameTxt.getText().trim());
        } catch (SQLException ex) {
            Logger.getLogger(Medicamentos.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (!existeMedicamento) {
            JOptionPane.showMessageDialog(this, "No existe un medicamento con ese nombre");
            return;
        }

        //Comprobación
        int opcion = JOptionPane.showOptionDialog(
                null,
                "¿Quieres continuar?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new Object[]{"Continuar", "Cancelar"},
                "Continuar");

        if (opcion == JOptionPane.YES_OPTION) {
            //Eliminar el medicamento
            try {
                //Crear la consulta
                String consulta = "DELETE FROM medicamentos WHERE Nombre = ?";
                PreparedStatement sentencia = conexion.prepareStatement(consulta);
                sentencia.setString(1, MedNameTxt.getText().trim());
                int row = sentencia.executeUpdate();
                JOptionPane.showMessageDialog(this, "Medicamento eliminado correctamente");
                MostrarMed();
                Clear();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());
            }

        } else if (opcion == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "La operación ha sido cancelada");
        }

    }//GEN-LAST:event_MedDelActionPerformed

    //Seleciconar los elementos de la tabla y mostrarlos en los campos de escritura
    private void MedTbMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MedTbMousePressed
        DefaultTableModel model = (DefaultTableModel) MedTb.getModel();
        int indice = MedTb.getSelectedRow();
        MedNameTxt.setText(model.getValueAt(indice, 1).toString());
        MedPriceTxt.setText(model.getValueAt(indice, 2).toString());
        MedCantTxt.setText(model.getValueAt(indice, 3).toString());
        MedFabDate.setDate((java.util.Date) model.getValueAt(indice, 4));
        MedCadDate.setDate((java.util.Date) model.getValueAt(indice, 5));
        MedProvSel.setSelectedItem(model.getValueAt(indice, 6));
    }//GEN-LAST:event_MedTbMousePressed

    //Vaciar los elementos seleccionados de la tabla
    private void MedTabRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedTabRefreshActionPerformed
        Clear();
        MostrarMed();
    }//GEN-LAST:event_MedTabRefreshActionPerformed

    //Editar medicamento
    private void MedEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedEditActionPerformed

        //Comprobar que se introducen los datos requeridos
        if (MedPriceTxt.getText().isEmpty() || MedCantTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce los datos que faltan para poder continuar");
        }
        //Comprobar que se introduce un número decimal en el precio
        if (!esNumeroDecimal(MedPriceTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo precio solo puede contener números o números decimales (no utilizar coma)");
            return;
        }
        //Comprobar que se introduce un número entero en cantidad
        if (!esNumero(MedCantTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo stock solo puede contener números enteros");
            return;
        }

        // Validar que la fecha seleccionada no es posterior a la fecha actual
        if (ComprobarFecha.esFechaPosterior(MedFabDate.getDate())) {
            JOptionPane.showMessageDialog(this, "La fecha de fabricación no puede ser posterior a la fecha actual");
            return;
        }

        //Comprobar proveedor       
        if (MedProvSel.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un proveedor");
            return;

        } else {

            //Comprobación
            int opcion = JOptionPane.showOptionDialog(
                    null,
                    "¿Quieres continuar?",
                    "Confirmación",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    new Object[]{"Continuar", "Cancelar"},
                    "Continuar");

            if (opcion == JOptionPane.YES_OPTION) {
                try {
                    //Almacena las fechas de fabricación y caducidad
                    FabDate = MedFabDate.getDate();
                    ExpDate = MedCadDate.getDate();
                    myFabDate = new java.sql.Date(FabDate.getTime());
                    myExpDate = new java.sql.Date(ExpDate.getTime());

                    //Crea la consulta
                    String actualizacion = "UPDATE Medicamentos SET pvp=?, stock=?, fabricacion=?, caducidad=?, idProveedor=(SELECT IdProveedor FROM proveedores WHERE empresa = ?) WHERE id IN (SELECT id FROM (SELECT id FROM medicamentos WHERE nombre=?) AS temp);";
                    PreparedStatement sentencia = conexion.prepareStatement(actualizacion);
                    //Pasa los datos la consulta
                    sentencia.setDouble(1, Double.parseDouble(MedPriceTxt.getText().trim()));
                    sentencia.setInt(2, Integer.parseInt(MedCantTxt.getText().trim()));
                    sentencia.setDate(3, myFabDate);
                    sentencia.setDate(4, myExpDate);
                    sentencia.setString(5, MedProvSel.getSelectedItem().toString());
                    sentencia.setString(6, MedNameTxt.getText().trim());

                    int row = sentencia.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Medicamento actualizado con éxito");
                    MostrarMed();
                    Clear();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());
                }
            } else if (opcion == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, "La operación ha sido cancelada");
            }
        }
    }//GEN-LAST:event_MedEditActionPerformed

    //Buscar un medicamento en la base de datos
    private void MedConsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedConsActionPerformed
        if (MedNameTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce el nombre del medicamento a consultar");
        }
        //Validar el nombre del medicamento
        if (!ValidadorDeCadenas.contieneLetrasyNumeros(MedNameTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo nombre solo puede contener letras y números");
            return;
        }
        //Muestra los datos del medicamento
        try {
            String consulta = "SELECT m.Id, m.Nombre, m.Pvp, m.stock, m.Fabricacion, m.Caducidad, p.Empresa FROM medicamentos m INNER JOIN proveedores p ON m.idProveedor = p.IdProveedor WHERE nombre LIKE ?";
            PreparedStatement pstm = conexion.prepareStatement(consulta);
            pstm.setString(1, MedNameTxt.getText().trim() + "%");
            ResultSet rs = pstm.executeQuery();

            if (rs.next()) {
                DefaultTableModel model = (DefaultTableModel) MedTb.getModel();
                model.setRowCount(0); // clear previous data
                rs.beforeFirst();
                MedTb.setModel(DbUtils.resultSetToTableModel(rs));

            } else {
                JOptionPane.showMessageDialog(this, "No se encontraron resultados");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + e.getMessage());
        }
    }//GEN-LAST:event_MedConsActionPerformed

    //Botonoes de cambio de ventana
    private void MenuEmpleadosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MenuEmpleadosMousePressed
        new Empleados().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_MenuEmpleadosMousePressed

    private void MenuProveedoresMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MenuProveedoresMousePressed
        new Proveedores().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_MenuProveedoresMousePressed

    private void MedMenuVtasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MedMenuVtasMousePressed
        new Ventas().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_MedMenuVtasMousePressed

    //Botón de minimizar pantalla
    private void minimizarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizarMousePressed
        this.setState(this.ICONIFIED);
    }//GEN-LAST:event_minimizarMousePressed

    //Cambiar de usuario
    private void logOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logOutActionPerformed
        JOptionPane.showMessageDialog(this, "Se ha cerrado la sesión  del usuario " + Login.loggedInUser);
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logOutActionPerformed

    private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
        initialClick = evt.getPoint();
    }//GEN-LAST:event_jPanel1MousePressed

    private void jPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseDragged
        int thisX = frame.getLocation().x;
        int thisY = frame.getLocation().y;

        int xMoved = evt.getX() - initialClick.x;
        int yMoved = evt.getY() - initialClick.y;

        int X = thisX + xMoved;
        int Y = thisY + yMoved;

        frame.setLocation(X, Y);
    }//GEN-LAST:event_jPanel1MouseDragged

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Medicamentos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BrandMed;
    private javax.swing.JLabel LogoMed;
    private javax.swing.JButton MedAdd;
    private javax.swing.JLabel MedCad;
    private com.toedter.calendar.JDateChooser MedCadDate;
    private javax.swing.JLabel MedCant;
    private javax.swing.JLabel MedCant1;
    private javax.swing.JTextField MedCantTxt;
    private javax.swing.JButton MedCons;
    private javax.swing.JButton MedDel;
    private javax.swing.JButton MedEdit;
    private javax.swing.JLabel MedFab;
    private com.toedter.calendar.JDateChooser MedFabDate;
    private javax.swing.JLabel MedListTitle;
    private javax.swing.JLabel MedMenuVtas;
    private javax.swing.JLabel MedName;
    private javax.swing.JTextField MedNameTxt;
    private javax.swing.JLabel MedPrice;
    private javax.swing.JTextField MedPriceTxt;
    private javax.swing.JLabel MedProv;
    private javax.swing.JComboBox<String> MedProvSel;
    private javax.swing.JButton MedTabRefresh;
    private javax.swing.JTable MedTb;
    private javax.swing.JLabel MedX;
    private javax.swing.JLabel MedicamentosTitle;
    private javax.swing.JLabel MenuEmpleados;
    private javax.swing.JLabel MenuProveedores;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logOut;
    private javax.swing.JLabel minimizar;
    private javax.swing.JLabel usuario;
    // End of variables declaration//GEN-END:variables
}
