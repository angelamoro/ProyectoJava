
package farmaciacurasana;

import java.sql.SQLException;

public class FarmaciaCuraSana {

    public static void main(String[] args) throws SQLException {
    
    }
    
}
