package farmaciacurasana;

import java.awt.Point;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import misClases.Conexion;
import misClases.Encriptador;
import misClases.ValidadorDeCadenas;
import static misClases.ValidadorDeTelefono.esValido;
import misClases.ValidarPassword;
import misClases.ComprobadorDeEmpleado;
import misClases.ComprobarFecha;
import net.proteanit.sql.DbUtils;

public class Empleados extends javax.swing.JFrame {

    public Empleados() {
        initComponents();
        //Abro la conexion
        try {
            conexion = Conexion.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexión con la base de datos.");
            System.exit(0);
        }
        //Cambiar el icono
        setIconImage(new ImageIcon(getClass().getResource("../Images/logo .png")).getImage());
        MostrarEmpleados();
        usuario.setText(Login.loggedInUser);
        //Desplazar ventana
        jPanel1 = new JPanel();
        frame = this;
    }

    public static Connection conexion;
    public static Statement st = null;
    public static ResultSet rs = null;
    private static Point initialClick;
    private JFrame frame;
    java.util.Date cumpleDate;
    java.sql.Date myCumpleDate;

    //Mostrar la tabla empleados
    public void MostrarEmpleados() {
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(" SELECT * FROM Empleados ORDER BY IdEmpleado");
            Empleadostb.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + e.getMessage());
        }
    }

    //Vaciar los formularios a rellenar
    public void Clear() {
        nombre.setText("");
        usuarioTxt.setText("");
        birthdate.setDate(Calendar.getInstance().getTime());
        telf.setText("");
        Psswd.setText("");
        SexSelection.setSelectedItem(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        BrandGestores = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        LogoGestores = new javax.swing.JLabel();
        ProveedoresMenu = new javax.swing.JLabel();
        almacenMenu = new javax.swing.JLabel();
        ventasMenu = new javax.swing.JLabel();
        MedCant1 = new javax.swing.JLabel();
        usuario = new javax.swing.JLabel();
        logOut = new javax.swing.JButton();
        GestoresTitle = new javax.swing.JLabel();
        GestName = new javax.swing.JLabel();
        GestCumple = new javax.swing.JLabel();
        GestTlf = new javax.swing.JLabel();
        GestPsswd = new javax.swing.JLabel();
        GestSex = new javax.swing.JLabel();
        GestId = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        usuarioTxt = new javax.swing.JTextField();
        SexSelection = new javax.swing.JComboBox<>();
        AddEmpleado = new javax.swing.JButton();
        ActualizarEmpleado = new javax.swing.JButton();
        EliminarEmpleado = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Empleadostb = new javax.swing.JTable();
        GestListTittle = new javax.swing.JLabel();
        GestX = new javax.swing.JLabel();
        telf = new javax.swing.JTextField();
        ConsultaEmpleados = new javax.swing.JButton();
        ReiniciarTabla = new javax.swing.JButton();
        birthdate = new com.toedter.calendar.JDateChooser();
        minmizar = new javax.swing.JLabel();
        Aviso = new javax.swing.JLabel();
        Psswd = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel1MouseDragged(evt);
            }
        });
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 153, 255));

        BrandGestores.setFont(new java.awt.Font("Dubai", 1, 36)); // NOI18N
        BrandGestores.setForeground(new java.awt.Color(255, 255, 255));
        BrandGestores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BrandGestores.setText("Cura Sana");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        LogoGestores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logo .png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LogoGestores)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LogoGestores)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        ProveedoresMenu.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        ProveedoresMenu.setForeground(new java.awt.Color(255, 255, 255));
        ProveedoresMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ProveedoresMenu.setText("Proveedores");
        ProveedoresMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ProveedoresMenuMousePressed(evt);
            }
        });

        almacenMenu.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        almacenMenu.setForeground(new java.awt.Color(255, 255, 255));
        almacenMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        almacenMenu.setText("Almacen");
        almacenMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                almacenMenuMousePressed(evt);
            }
        });

        ventasMenu.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        ventasMenu.setForeground(new java.awt.Color(255, 255, 255));
        ventasMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ventasMenu.setText("Ventas");
        ventasMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ventasMenuMousePressed(evt);
            }
        });

        MedCant1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        MedCant1.setForeground(new java.awt.Color(255, 255, 255));
        MedCant1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MedCant1.setText("Usuario:");

        usuario.setFont(new java.awt.Font("Consolas", 0, 18)); // NOI18N
        usuario.setForeground(new java.awt.Color(255, 255, 255));
        usuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        usuario.setText("usuario");

        logOut.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        logOut.setText("Salir");
        logOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logOutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BrandGestores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(almacenMenu, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
            .addComponent(ProveedoresMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(ventasMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(MedCant1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(usuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(logOut)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BrandGestores)
                .addGap(36, 36, 36)
                .addComponent(almacenMenu)
                .addGap(18, 18, 18)
                .addComponent(ProveedoresMenu)
                .addGap(18, 18, 18)
                .addComponent(ventasMenu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 165, Short.MAX_VALUE)
                .addComponent(MedCant1)
                .addGap(18, 18, 18)
                .addComponent(usuario)
                .addGap(18, 18, 18)
                .addComponent(logOut, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );

        GestoresTitle.setFont(new java.awt.Font("Dubai", 1, 36)); // NOI18N
        GestoresTitle.setForeground(new java.awt.Color(0, 0, 0));
        GestoresTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        GestoresTitle.setText("Empleados");

        GestName.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        GestName.setForeground(new java.awt.Color(0, 0, 0));
        GestName.setText("Usuario:");

        GestCumple.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        GestCumple.setForeground(new java.awt.Color(0, 0, 0));
        GestCumple.setText("Cumpleaños:");

        GestTlf.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        GestTlf.setForeground(new java.awt.Color(0, 0, 0));
        GestTlf.setText("Teléfono:");

        GestPsswd.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        GestPsswd.setForeground(new java.awt.Color(0, 0, 0));
        GestPsswd.setText("Contraseña:");

        GestSex.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        GestSex.setForeground(new java.awt.Color(0, 0, 0));
        GestSex.setText("Sexo:");

        GestId.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        GestId.setForeground(new java.awt.Color(0, 0, 0));
        GestId.setText("Nombre:");

        SexSelection.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "No especificado", "Mujer", "Hombre" }));

        AddEmpleado.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        AddEmpleado.setText("Añadir");
        AddEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddEmpleadoActionPerformed(evt);
            }
        });

        ActualizarEmpleado.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        ActualizarEmpleado.setText("Actualizar");
        ActualizarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActualizarEmpleadoActionPerformed(evt);
            }
        });

        EliminarEmpleado.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        EliminarEmpleado.setText("Eliminar");
        EliminarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarEmpleadoActionPerformed(evt);
            }
        });

        Empleadostb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Usuario", "Cumpleaños", "Teléfono", "Contraseña", "Sexo"
            }
        ));
        Empleadostb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                EmpleadostbMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(Empleadostb);

        GestListTittle.setFont(new java.awt.Font("Dubai", 0, 28)); // NOI18N
        GestListTittle.setForeground(new java.awt.Color(0, 0, 0));
        GestListTittle.setText("Listado de empleados");

        GestX.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        GestX.setForeground(new java.awt.Color(0, 153, 255));
        GestX.setText("X");
        GestX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                GestXMousePressed(evt);
            }
        });

        ConsultaEmpleados.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        ConsultaEmpleados.setText("Consultar");
        ConsultaEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultaEmpleadosActionPerformed(evt);
            }
        });

        ReiniciarTabla.setFont(new java.awt.Font("Dubai Medium", 1, 18)); // NOI18N
        ReiniciarTabla.setText("Refrescar");
        ReiniciarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReiniciarTablaActionPerformed(evt);
            }
        });

        minmizar.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        minmizar.setForeground(new java.awt.Color(0, 153, 255));
        minmizar.setText("-");
        minmizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                minmizarMousePressed(evt);
            }
        });

        Aviso.setText("⚠ ️ Al actualizar el empleado se debe actualizar la contraseña");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(18, 30, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(ConsultaEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(51, 51, 51)
                                        .addComponent(AddEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(42, 42, 42)
                                        .addComponent(ActualizarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(GestId, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(34, 34, 34)
                                                .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(GestName, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(44, 44, 44)
                                                .addComponent(usuarioTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(GestCumple, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(birthdate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                        .addGap(84, 84, 84)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(GestPsswd)
                                            .addComponent(GestTlf)
                                            .addComponent(GestSex))))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(telf, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(Psswd)
                                            .addComponent(SexSelection, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGap(40, 40, 40)
                                        .addComponent(EliminarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(95, 95, 95))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(GestListTittle)
                                        .addGap(100, 100, 100)
                                        .addComponent(ReiniciarTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 656, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(GestoresTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(minmizar)
                        .addGap(18, 18, 18)
                        .addComponent(GestX)
                        .addGap(20, 20, 20))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(218, 218, 218)
                        .addComponent(Aviso)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(GestX)
                            .addComponent(minmizar)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(GestoresTitle)))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(GestTlf)
                    .addComponent(telf, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(GestId))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(GestPsswd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Psswd))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SexSelection, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(GestSex)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(usuarioTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(GestName))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(GestCumple)
                            .addComponent(birthdate, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(32, 32, 32)
                .addComponent(Aviso)
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ActualizarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EliminarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ConsultaEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(GestListTittle)
                    .addComponent(ReiniciarTabla))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    //cerrar la aplicación
    private void GestXMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GestXMousePressed
        try {
            // Cerrar el objeto Statement
            if (st != null) {
                st.close();
            }
            // Cerrar la conexión a la base de datos
            if (conexion != null) {
                Conexion.closeConnection();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        dispose(); //Cierra la pantalla
    }//GEN-LAST:event_GestXMousePressed

    //Abrir las diferentes ventanas    
    private void almacenMenuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_almacenMenuMousePressed
        new Medicamentos().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_almacenMenuMousePressed

    private void ProveedoresMenuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProveedoresMenuMousePressed
        new Proveedores().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ProveedoresMenuMousePressed

    private void ventasMenuMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ventasMenuMousePressed
        new Ventas().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ventasMenuMousePressed

    //Añadir empleado
    private void AddEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddEmpleadoActionPerformed
        //Almacenar el cumpleaños
        cumpleDate = birthdate.getDate();
        myCumpleDate = new java.sql.Date(cumpleDate.getTime());
        //Comprobar que los campos mínimos están llenos
        if (nombre.getText().isEmpty() || usuarioTxt.getText().isEmpty() || telf.getText().isEmpty() || Psswd.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce los datos que faltan para poder continuar");
        }

        // Validar que el campo de nombre solo contiene letras
        if (!ValidadorDeCadenas.contieneSoloLetras(nombre.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo nombre solo puede contener letras");
            return;
        }

        // Validar que el campo de usuario solo contiene letras y números
        if (!ValidadorDeCadenas.contieneLetrasyNumeros(usuarioTxt.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo usuario solo debe contener letras y números");
            return;
        }

        //Comprobar si el usuario ya existe
        ComprobadorDeEmpleado comprobador = new ComprobadorDeEmpleado(conexion);
        try {
            if (comprobador.existeEmpleadoConNombre(usuarioTxt.getText().trim())) {
                JOptionPane.showMessageDialog(this, "Ya existe un empleado con el mismo usuario, por favor introduce un usuario nuevo");
                return;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Empleados.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Validar que la fecha seleccionada no es posterior a la fecha actual
        if (ComprobarFecha.esFechaPosterior(myCumpleDate)) {
            JOptionPane.showMessageDialog(this, "La fecha seleccionada no puede ser posterior a la fecha actual");
            return;
        }

        //Comprobar que el teléfono cumple con las especificaciones
        if (!esValido(telf.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El teléfono debe tener entre 9 y 12 dígitos y no contener caracteres que no sean números.");
            return;
        }

        try {

            // Validar que la contraseña cumple con las especificaciones
            ValidarPassword validador = new ValidarPassword();
            if (!validador.esValida(Psswd.getText())) {
                JOptionPane.showMessageDialog(this, "La contraseña no cumple con los requisitos de seguridad.\n" + "Longitud mínima de 8 caracteres y máxima de 20.\n"
                        + "Al menos una letra minúscula, una letra mayúscula, un número y un carácter especial (*@#$%^&+=!).\n" + "No puede contener espacios en blanco.");
                return;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());
        }

        //Almacena la contraseña en una variable
        String passwd = new String(Psswd.getText());

        // Encriptar la contraseña
        String hashedPasswd = Encriptador.encriptar(passwd);

        //Comprobar que el teléfono cumple con las especificaciones
        if (SexSelection.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Seleccione una opción para sexo");
            return;
        }

        //Comprobación
        int opcion = JOptionPane.showOptionDialog(
                null,
                "¿Quieres continuar?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new Object[]{"Continuar", "Cancelar"},
                "Continuar");

        if (opcion == JOptionPane.YES_OPTION) {
            try {
                //Creo la consulta
                String consulta = "INSERT INTO Empleados (nombre, usuario, Birthday, telefono, Psswrd, sexo) values (?, ?, ?, ?, ?, ?);";
                PreparedStatement sentencia = conexion.prepareStatement(consulta);

                sentencia.setString(1, nombre.getText().trim());
                sentencia.setString(2, usuarioTxt.getText().trim());
                sentencia.setDate(3, myCumpleDate);
                sentencia.setString(4, telf.getText().trim());
                sentencia.setString(5, hashedPasswd);
                sentencia.setString(6, SexSelection.getSelectedItem().toString());
                int row = sentencia.executeUpdate();
                JOptionPane.showMessageDialog(this, "Empleado añadido correctamente");
                MostrarEmpleados();
                Clear();

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());
            }
        } else if (opcion == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "La operación ha sido cancelada");
        }
    }//GEN-LAST:event_AddEmpleadoActionPerformed

    //Eliminar usuario
    private void EliminarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarEmpleadoActionPerformed
        //Comprobar que el campo no esta vacío
        if (usuarioTxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce los datos del empleado a eliminar");
        } else {

            // Validar que el campo de usuario solo contiene letras y números
            if (!ValidadorDeCadenas.contieneLetrasyNumeros(usuarioTxt.getText().trim())) {
                JOptionPane.showMessageDialog(this, "El campo usuario solo debe contener letras y números");
                return;
            } else {
                try {
                    //Comprobar si el usuario ya existe
                    ComprobadorDeEmpleado comprobador = new ComprobadorDeEmpleado(conexion);
                    if (!comprobador.existeEmpleadoConNombre(usuarioTxt.getText().trim())) {
                        JOptionPane.showMessageDialog(this, "No existe un empleado con ese usuario, por favor introduce un usuario nuevo");
                    } else {
                        //Comprobación
                        int opcion = JOptionPane.showOptionDialog(
                                null,
                                "¿Quieres continuar?",
                                "Confirmación",
                                JOptionPane.YES_NO_OPTION,
                                JOptionPane.QUESTION_MESSAGE,
                                null,
                                new Object[]{"Continuar", "Cancelar"},
                                "Continuar");

                        if (opcion == JOptionPane.YES_OPTION) {
                            try {
                                //Creo la consulta
                                String consulta = "DELETE FROM Empleados WHERE IdEmpleado = (SELECT IdEmpleado FROM (SELECT * FROM Empleados) AS e WHERE e.usuario = ?)";
                                PreparedStatement sentencia = conexion.prepareStatement(consulta);
                                sentencia.setString(1, usuarioTxt.getText().trim());
                                int row = sentencia.executeUpdate();
                                JOptionPane.showMessageDialog(this, "Empleado eliminado correctamente");
                                MostrarEmpleados();
                                Clear();

                            } catch (SQLException e) {
                                JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());

                            }
                        } else if (opcion == JOptionPane.NO_OPTION) {
                            JOptionPane.showMessageDialog(null, "La operación ha sido cancelada");
                        }
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Empleados.class
                            .getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_EliminarEmpleadoActionPerformed

    //Seleccionar los datos de la tabla y subirlos a los elementos de display text
    private void EmpleadostbMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EmpleadostbMousePressed
        DefaultTableModel model = (DefaultTableModel) Empleadostb.getModel();
        int indice = Empleadostb.getSelectedRow();
        nombre.setText(model.getValueAt(indice, 1).toString());
        usuarioTxt.setText(model.getValueAt(indice, 2).toString());
        birthdate.setDate((java.util.Date) model.getValueAt(indice, 3));
        telf.setText(model.getValueAt(indice, 4).toString());
        //Psswd.setText(model.getValueAt(indice, 5).toString());
        SexSelection.setSelectedItem(model.getValueAt(indice, 6));
    }//GEN-LAST:event_EmpleadostbMousePressed

    //Botón de refrescar tabla
    private void ReiniciarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReiniciarTablaActionPerformed
        Clear();
        MostrarEmpleados();
    }//GEN-LAST:event_ReiniciarTablaActionPerformed

    //Actualizar empleado
    private void ActualizarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActualizarEmpleadoActionPerformed
        //Almacenar el cumpleaños introducido
        cumpleDate = birthdate.getDate();
        myCumpleDate = new java.sql.Date(cumpleDate.getTime());

        //Comprobbar que están los datos requeridos
        if (nombre.getText().isEmpty() || usuarioTxt.getText().isEmpty() || telf.getText().isEmpty() || Psswd.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce los datos que faltan para poder continuar");
        } else {

            // Validar que el campo de nombre solo contengan letras
            if (!ValidadorDeCadenas.contieneSoloLetras(nombre.getText().trim())) {
                JOptionPane.showMessageDialog(this, "El campo nombre solo debe contener letras, por favor no utilice espacios");
                return;
            }
            // Validar que el campo de usuario solo contengan letras y numeros
            if (!ValidadorDeCadenas.contieneLetrasyNumeros(usuarioTxt.getText().trim())) {
                JOptionPane.showMessageDialog(this, "El campo usuario solo debe contener letras y números");
            } else {

                // Valida la contraseña
                ValidarPassword validador = new ValidarPassword();
                if (!validador.esValida(Psswd.getText())) {
                    JOptionPane.showMessageDialog(this, "La contraseña no cumple con los requisitos de seguridad.\n" + "Longitud mínima de 8 caracteres y máxima de 20.\n"
                            + "Al menos una letra minúscula, una letra mayúscula, un número y un carácter especial (*@#$%^&+=!).\n" + "No puede contener espacios en blanco.");
                    return;
                }

                // Validar que la fecha seleccionada no es posterior a la fecha actual
                if (ComprobarFecha.esFechaPosterior(myCumpleDate)) {
                    JOptionPane.showMessageDialog(this, "La fecha seleccionada no puede ser posterior a la fecha actual");
                    return;
                }

                //Comprueba que el teléfono cumple con las especificaciones
                if (!esValido(telf.getText().trim())) {
                    JOptionPane.showMessageDialog(this, "El teléfono debe tener entre 9 y 12 dígitos y no contener caracteres que no sean números.");
                    return;
                }

                //Almacena la contraseña introducida
                String passwd = new String(Psswd.getText());

                // Encripta la contraseña
                String hashedPasswd = Encriptador.encriptar(passwd);

                //Comprobación
                int opcion = JOptionPane.showOptionDialog(
                        null,
                        "¿Quieres continuar?",
                        "Confirmación",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        new Object[]{"Continuar", "Cancelar"},
                        "Continuar");

                if (opcion == JOptionPane.YES_OPTION) {
                    try {
                        cumpleDate = birthdate.getDate();
                        myCumpleDate = new java.sql.Date(cumpleDate.getTime());
                        String actualizacion = "UPDATE Empleados SET nombre=?, Birthday=?, telefono=?, psswrd=?, sexo=? WHERE IdEmpleado =(SELECT IdEmpleado FROM (SELECT * FROM Empleados) AS e WHERE e.Usuario = ?)";
                        PreparedStatement sentencia = conexion.prepareStatement(actualizacion);
                        sentencia.setString(1, nombre.getText().trim());
                        sentencia.setDate(2, myCumpleDate);
                        sentencia.setString(3, telf.getText().trim());
                        sentencia.setString(4, hashedPasswd);
                        sentencia.setString(5, SexSelection.getSelectedItem().toString());
                        sentencia.setString(6, usuarioTxt.getText().trim());
                        int row = sentencia.executeUpdate();
                        JOptionPane.showMessageDialog(this, "Empleado actualizado correctamente");
                        MostrarEmpleados();
                        Clear();

                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos. Error: " + e.getMessage());
                    }

                } else if (opcion == JOptionPane.NO_OPTION) {
                    JOptionPane.showMessageDialog(null, "La operación ha sido cancelada");
                }
            }
        }
    }//GEN-LAST:event_ActualizarEmpleadoActionPerformed

//Consulta que el empleado existe en la base de datos
    private void ConsultaEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultaEmpleadosActionPerformed
        //Comprobar que están los datos requeridos
        if (nombre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introduce el nombre del empleado a consultar");
            return;
        }
        // Validar que el campo de nombre solo contengan letras
        if (!ValidadorDeCadenas.contieneSoloLetras(nombre.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El campo nombre solo puede contener letras");
            return;
        }
        try {
            String consulta = "SELECT * FROM Empleados WHERE Nombre LIKE ?";
            PreparedStatement pstm = conexion.prepareStatement(consulta);
            pstm.setString(1, nombre.getText().trim() + "%");
            ResultSet rs = pstm.executeQuery();
            // Mover el cursor al principio del resultado
            rs.beforeFirst();
            if (rs.next()) {
                DefaultTableModel model = (DefaultTableModel) Empleadostb.getModel();
                model.setRowCount(0); // clear previous data
                rs.beforeFirst();
                Empleadostb.setModel(DbUtils.resultSetToTableModel(rs));

            } else {
                JOptionPane.showMessageDialog(this, "No se encontraron resultados");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Algo ha ido mal, revisa los datos introducidos" + e.getMessage());
        }
    }//GEN-LAST:event_ConsultaEmpleadosActionPerformed

    //Minimizar la pantalla
    private void minmizarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minmizarMousePressed
        this.setState(this.ICONIFIED);

    }//GEN-LAST:event_minmizarMousePressed

    //Cambiar de usuario
    private void logOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logOutActionPerformed
        JOptionPane.showMessageDialog(this, "Se ha cerrado la sesión  del usuario " + Login.loggedInUser);
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logOutActionPerformed

    //Arrastrar pantalla
    private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
        initialClick = evt.getPoint();
    }//GEN-LAST:event_jPanel1MousePressed

    private void jPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseDragged
        int thisX = frame.getLocation().x;
        int thisY = frame.getLocation().y;

        int xMoved = evt.getX() - initialClick.x;
        int yMoved = evt.getY() - initialClick.y;

        int X = thisX + xMoved;
        int Y = thisY + yMoved;

        frame.setLocation(X, Y);
    }//GEN-LAST:event_jPanel1MouseDragged

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Empleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ActualizarEmpleado;
    private javax.swing.JButton AddEmpleado;
    private javax.swing.JLabel Aviso;
    private javax.swing.JLabel BrandGestores;
    private javax.swing.JButton ConsultaEmpleados;
    private javax.swing.JButton EliminarEmpleado;
    private javax.swing.JTable Empleadostb;
    private javax.swing.JLabel GestCumple;
    private javax.swing.JLabel GestId;
    private javax.swing.JLabel GestListTittle;
    private javax.swing.JLabel GestName;
    private javax.swing.JLabel GestPsswd;
    private javax.swing.JLabel GestSex;
    private javax.swing.JLabel GestTlf;
    private javax.swing.JLabel GestX;
    private javax.swing.JLabel GestoresTitle;
    private javax.swing.JLabel LogoGestores;
    private javax.swing.JLabel MedCant1;
    private javax.swing.JLabel ProveedoresMenu;
    private javax.swing.JPasswordField Psswd;
    private javax.swing.JButton ReiniciarTabla;
    private javax.swing.JComboBox<String> SexSelection;
    private javax.swing.JLabel almacenMenu;
    private com.toedter.calendar.JDateChooser birthdate;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logOut;
    private javax.swing.JLabel minmizar;
    private javax.swing.JTextField nombre;
    private javax.swing.JTextField telf;
    private javax.swing.JLabel usuario;
    private javax.swing.JTextField usuarioTxt;
    private javax.swing.JLabel ventasMenu;
    // End of variables declaration//GEN-END:variables
}
